package PayrollV2.model;

// ORIGINAL SIGNATURE: public class Payslip {
// UPDATE TO:
import java.io.Serializable;

// WHY: The Payslip object itself needs to be saved as a file for the employee to read later.
public class Payslip implements Serializable {
    private static final long serialVersionUID = 1L;
    
    // Core requested variables
    private double totalHours;
    private double grossPay;
    private double totalDeductions;
    private double netPay;
    
    // Additional breakdown variables for the UI receipt
    private double overtimeHours;
    private double sss;
    private double philhealth;
    private double pagibig;
    private double tax;
    private double loan;

    public Payslip(double totalHours, double overtimeHours, double grossPay, 
                   double sss, double philhealth, double pagibig, double tax, double loan, 
                   double totalDeductions, double netPay) {
        this.totalHours = totalHours;
        this.overtimeHours = overtimeHours;
        this.grossPay = grossPay;
        this.sss = sss;
        this.philhealth = philhealth;
        this.pagibig = pagibig;
        this.tax = tax;
        this.loan = loan;
        this.totalDeductions = totalDeductions;
        this.netPay = netPay;
    }

    // Getters
    public double getTotalHours() { return totalHours; }
    public double getOvertimeHours() { return overtimeHours; }
    public double getGrossPay() { return grossPay; }
    public double getSss() { return sss; }
    public double getPhilhealth() { return philhealth; }
    public double getPagibig() { return pagibig; }
    public double getTax() { return tax; }
    public double getLoan() { return loan; }
    public double getTotalDeductions() { return totalDeductions; }
    public double getNetPay() { return netPay; }
}
package PayrollV2.controller;

import PayrollV2.model.DailyTimeRecord;
import PayrollV2.util.FileStorageUtil;
import java.io.File;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TimeKeepingController {

    private String empID;
    private String fileName;

    // WHY: We initialize the controller with the specific employee's ID so it always 
    // knows exactly which .dat file to read from and write to.
    public TimeKeepingController(String empID) {
        this.empID = empID;
        this.fileName = empID + "_time_records.dat";
    }

    // WHY: This retrieves the records for the table. If they don't exist yet, it generates them.
    public List<DailyTimeRecord> getOrInitializeRecords(String cutoffPeriod) {
        List<DailyTimeRecord> records = loadRecords();
        
        if (records == null || records.isEmpty()) {
            records = generateBlankRecords(cutoffPeriod);
            saveRecords(records);
        }
        return records;
    }

    // WHY: Automatically creates a row for every day in the cutoff period based on the current month.
    private List<DailyTimeRecord> generateBlankRecords(String cutoffPeriod) {
        List<DailyTimeRecord> newRecords = new ArrayList<>();
        LocalDate today = LocalDate.now(); // Gets current system date
        int year = today.getYear();
        int month = today.getMonthValue();
        
        int startDay = 1;
        int endDay = 15;

        // If the cutoff is the second half of the month, adjust the start and end days.
        if (cutoffPeriod != null && cutoffPeriod.contains("16")) {
            startDay = 16;
            // WHY: YearMonth accounts for leap years and months with 30 vs 31 days automatically.
            YearMonth yearMonthObject = YearMonth.of(year, month);
            endDay = yearMonthObject.lengthOfMonth(); 
        }

        for (int day = startDay; day <= endDay; day++) {
            LocalDate date = LocalDate.of(year, month, day);
            newRecords.add(new DailyTimeRecord(empID, date.toString()));
        }
        return newRecords;
    }

    // WHY: This single method handles both Time In and Time Out based on the current state of today's record.
    public String punchTime() {
        List<DailyTimeRecord> records = loadRecords();
        if (records == null) return "Error: No time records found. Please initialize first.";

        String todayStr = LocalDate.now().toString();
        // Formats time to standard 24-hour clock (e.g., 14:30:00)
        String currentTime = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));

        for (DailyTimeRecord record : records) {
            // Find the record that matches today's date
            if (record.getDate().equals(todayStr)) {
                
                // Rule 1: Check for leaves
                if (record.getLeaveStatus().equals("APPROVED")) {
                    return "You are on an approved leave today. No time logging required.";
                }
                
                // Rule 2: If Time In is empty, log Time In
                if (record.getTimeIn().equals("Not Logged")) {
                    record.setTimeIn(currentTime);
                    saveRecords(records);
                    return "Successfully Punched In at " + currentTime;
                } 
                // Rule 3: If Time In exists but Time Out is empty, log Time Out
                else if (record.getTimeOut().equals("Not Logged")) {
                    record.setTimeOut(currentTime);
                    saveRecords(records);
                    return "Successfully Punched Out at " + currentTime;
                } 
                // Rule 4: Both are filled
                else {
                    return "You have already completed your time logs for today.";
                }
            }
        }
        return "Today's date (" + todayStr + ") is not within your current cutoff period.";
    }
    
    // WHY: This allows the employer to override the default "NONE" or "PENDING" leave status.
    // It is placed in this controller because this controller already knows how to read/write the time files.
    public String updateLeaveStatus(String targetDate, String newStatus) {
        List<DailyTimeRecord> records = loadRecords();
        if (records == null) return "Error: Could not load records for employee.";

        boolean recordFound = false;
        for (DailyTimeRecord record : records) {
            if (record.getDate().equals(targetDate)) {
                record.setLeaveStatus(newStatus);
                
                // If leave is approved, we clear out any existing time logs for that day to prevent logical conflicts.
                if (newStatus.equals("APPROVED")) {
                    record.setTimeIn("ON LEAVE");
                    record.setTimeOut("ON LEAVE");
                }
                recordFound = true;
                break; // Stop searching once we find the exact day
            }
        }

        if (recordFound) {
            saveRecords(records);
            return "Leave status for " + targetDate + " updated to " + newStatus;
        } else {
            return "Error: Date not found in the current cutoff period.";
        }
    }
    
    // WHY: This allows the employee to initiate a leave request. It sets the status to "PENDING", 
    // which the employer will later see in the Time Viewer and can change to APPROVED or DENIED.
    public String requestLeave(String requestDate) {
        List<DailyTimeRecord> records = loadRecords();
        if (records == null) return "Error: Could not load your time records.";

        for (DailyTimeRecord record : records) {
            // Find the exact date the employee typed in
            if (record.getDate().equals(requestDate)) {
                
                // Only allow requests if no leave is currently active or pending
                if (record.getLeaveStatus().equals("NONE")) {
                    record.setLeaveStatus("PENDING");
                    saveRecords(records);
                    return "Success: Leave request for " + requestDate + " submitted.";
                } else {
                    return "Notice: Leave for this date is already " + record.getLeaveStatus() + ".";
                }
            }
        }
        return "Error: Date '" + requestDate + "' not found in your current cutoff period.";
    }

    // Helper methods for File I/O
    @SuppressWarnings("unchecked")
    private List<DailyTimeRecord> loadRecords() {
        File file = new File(fileName);
        if (file.exists()) {
            try {
                return (List<DailyTimeRecord>) FileStorageUtil.loadData(fileName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private void saveRecords(List<DailyTimeRecord> records) {
        try {
            // WHY: ArrayList implements Serializable, so we can cast the List and save it directly.
            FileStorageUtil.saveData((java.io.Serializable) records, fileName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
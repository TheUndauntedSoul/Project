package payrollsystem.model;

import java.io.Serializable;
import java.time.LocalDate;

public class PayslipRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private final LocalDate generatedDate;
    private final double grossPay;
    private final double netPay;
    private final String payslipText;

    public PayslipRecord(LocalDate generatedDate, double grossPay, double netPay, String payslipText) {
        this.generatedDate = generatedDate;
        this.grossPay = grossPay;
        this.netPay = netPay;
        this.payslipText = payslipText;
    }

    public LocalDate getGeneratedDate() { return generatedDate; }
    public double getGrossPay() { return grossPay; }
    public double getNetPay() { return netPay; }
    public String getPayslipText() { return payslipText; }
    
    public java.time.LocalDate getDate() {
        return generatedDate; // Note: if your variable at the top is named something else, match it here!
    }    
}

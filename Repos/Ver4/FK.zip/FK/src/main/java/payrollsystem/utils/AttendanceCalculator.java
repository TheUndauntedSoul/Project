package payrollsystem.utils;

import payrollsystem.model.DailyTimeRecord;
import payrollsystem.model.Employee;
import payrollsystem.model.AttendanceSummary;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import payrollsystem.model.AttendanceSummary;
import payrollsystem.model.DailyTimeRecord;
import payrollsystem.model.Employee;

public class AttendanceCalculator {

    public static payrollsystem.model.AttendanceSummary calculateMetrics(
            payrollsystem.model.Employee emp, 
            java.util.List<payrollsystem.model.DailyTimeRecord> records) {
        
        double totalBasicHours = 0;
        double totalOtHours = 0;
        double totalLateUndertimeHours = 0;
        
        
        for (payrollsystem.model.DailyTimeRecord dtr : records) {
            
            // 1. HOLIDAY FLAG INTEGRATION
            String holidayType = payrollsystem.utils.PhilippineHolidayService.getHolidayType(dtr.getDate());
            
            if (holidayType.equals("REGULAR")) {
                dtr.setRegularHoliday(true);
                dtr.setSpecialHoliday(false);
            } else if (holidayType.equals("SPECIAL")) {
                dtr.setRegularHoliday(false);
                dtr.setSpecialHoliday(true);
            } else {
                dtr.setRegularHoliday(false);
                dtr.setSpecialHoliday(false);
            }

            // 2. TIME CALCULATIONS WITH SHIFT CLAMPING
            if (dtr.getTimeIn() != null && dtr.getTimeOut() != null) {
                
                // Define the strict shift boundaries
                java.time.LocalTime shiftStart = java.time.LocalTime.of(8, 0);
                java.time.LocalTime shiftEnd = java.time.LocalTime.of(17, 0); // 5:00 PM
                
                // --- A. CLAMP EARLY IN ---
                // If they clock in before 8:00 AM, payable time starts at 8:00 AM.
                java.time.LocalTime effectiveIn = dtr.getTimeIn();
                if (effectiveIn.isBefore(shiftStart)) {
                    effectiveIn = shiftStart;
                }

                // --- B. LATE PENALTY ---
                if (effectiveIn.isAfter(shiftStart)) {
                    long lateMinutes = java.time.temporal.ChronoUnit.MINUTES.between(shiftStart, effectiveIn);
                    if (lateMinutes > 0 && lateMinutes < 480) { 
                        totalLateUndertimeHours += (lateMinutes / 60.0);
                    }
                }

                // --- C. CLAMP AUTO-OT & CALCULATE APPROVED OT ---
                java.time.LocalTime effectiveOut = dtr.getTimeOut();
                double dailyOtHours = 0;

                if (effectiveOut.isAfter(shiftEnd)) {
                    // Check if Admin approved the overtime
                    if (dtr.isOtApproved()) {
                        long otMinutes = java.time.temporal.ChronoUnit.MINUTES.between(shiftEnd, effectiveOut);
                        dailyOtHours = otMinutes / 60.0;
                    }
                    
                    // Regardless of OT approval, we MUST clamp the effectiveOut to 5:00 PM 
                    // so the "Basic Pay" math below doesn't accidentally pay them twice for those hours.
                    effectiveOut = shiftEnd; 
                }

                // Prevent negative time if they came in early and left early
                if (effectiveOut.isBefore(effectiveIn)) {
                    effectiveOut = effectiveIn;
                }

                // --- D. PAYABLE MINUTES & LUNCH ---
                long payableMinutes = java.time.temporal.ChronoUnit.MINUTES.between(effectiveIn, effectiveOut);

                if (payableMinutes >= 300) { 
                    payableMinutes -= 60;
                }

                double basicHours = payableMinutes / 60.0;
                if (basicHours < 0) basicHours = 0;
                
                totalBasicHours += basicHours;
                totalOtHours += dailyOtHours; // Add the approved OT to the grand total
                
                // Note: totalOtHours remains 0 here because unapproved OT was clamped away.
            }
        }
        
        // Return the summary object
        return new payrollsystem.model.AttendanceSummary(totalBasicHours, totalOtHours, totalLateUndertimeHours);
    }

    private static double calculateDuration(LocalTime start, LocalTime end) {
        long minutes = ChronoUnit.MINUTES.between(start, end);
        if (minutes < 0) minutes += 24 * 60; 
        return minutes / 60.0;
    }

    private static double calculateNsdHours(LocalTime in, LocalTime out) {
        double nsdHours = 0.0;
        LocalTime current = in;
        long totalMinutes = ChronoUnit.MINUTES.between(in, out);
        if (totalMinutes < 0) totalMinutes += 24 * 60;
        
        for (int i = 0; i < totalMinutes; i++) {
            int hour = current.getHour();
            if (hour >= 22 || hour < 6) nsdHours += (1.0 / 60.0);
            current = current.plusMinutes(1);
        }
        return nsdHours;
    }
}
package payrollsystem.utils;

import payrollsystem.model.DailyTimeRecord;
import payrollsystem.model.Employee;
import payrollsystem.model.AttendanceSummary;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class AttendanceCalculator {

    public static AttendanceSummary calculateMetrics(Employee emp, List<DailyTimeRecord> records) {
        AttendanceSummary summary = new AttendanceSummary();
        
        LocalTime shiftStart = emp.getShiftStartTime();
        LocalTime shiftEnd = emp.getShiftEndTime();
        double standardShiftHours = calculateDuration(shiftStart, shiftEnd) - 1.0; 

        for (DailyTimeRecord dtr : records) {
            String status = dtr.getStatus();

            if (status.equals("ABSENT")) {
                summary.addAbsence();
            } 
            else if (status.equals("LEAVE APPROVED")) {
                summary.addPaidLeave();
                summary.addBasicWorked(standardShiftHours); 
            } 
            else if (status.equals("PRESENT") && dtr.getTimeIn() != null && dtr.getTimeOut() != null) {
                
                LocalTime tIn = dtr.getTimeIn();
                LocalTime tOut = dtr.getTimeOut();

                double totalHoursPunched = calculateDuration(tIn, tOut);
                if (totalHoursPunched > 5.0) totalHoursPunched -= 1.0; 

                double lateUnderHrs = 0;
                if (!dtr.isRestDay() && !dtr.isRegularHoliday() && !dtr.isSpecialHoliday()) {
                    if (tIn.isAfter(shiftStart)) lateUnderHrs += calculateDuration(shiftStart, tIn);
                    if (tOut.isBefore(shiftEnd)) lateUnderHrs += calculateDuration(tOut, shiftEnd);
                    summary.addLateUndertime(lateUnderHrs);
                }

                double baseHours = Math.min(totalHoursPunched, standardShiftHours);
                double excessHours = Math.max(0, totalHoursPunched - standardShiftHours);

                if (dtr.isRegularHoliday()) summary.addRegularHoliday(baseHours);
                else if (dtr.isSpecialHoliday()) summary.addSpecialHoliday(baseHours);
                else if (dtr.isRestDay()) summary.addRestDay(baseHours);
                else summary.addBasicWorked(baseHours);

                if (excessHours > 0 && dtr.isOtApproved()) summary.addRegularOt(excessHours);

                double nsd = calculateNsdHours(tIn, tOut);
                if (nsd > 0) summary.addNsd(nsd);
            }
        }
        return summary;
    }

    private static double calculateDuration(LocalTime start, LocalTime end) {
        long minutes = ChronoUnit.MINUTES.between(start, end);
        if (minutes < 0) minutes += 24 * 60; 
        return minutes / 60.0;
    }

    private static double calculateNsdHours(LocalTime in, LocalTime out) {
        double nsdHours = 0.0;
        LocalTime current = in;
        long totalMinutes = ChronoUnit.MINUTES.between(in, out);
        if (totalMinutes < 0) totalMinutes += 24 * 60;
        
        for (int i = 0; i < totalMinutes; i++) {
            int hour = current.getHour();
            if (hour >= 22 || hour < 6) nsdHours += (1.0 / 60.0);
            current = current.plusMinutes(1);
        }
        return nsdHours;
    }
}
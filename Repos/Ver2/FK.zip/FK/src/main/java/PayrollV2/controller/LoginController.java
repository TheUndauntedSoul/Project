package PayrollV2.controller;

import PayrollV2.model.Employee;
import PayrollV2.util.FileStorageUtil;
import java.io.File;

public class LoginController {

    // WHY: Returning a status string instead of directly opening windows keeps the Controller 
    // completely decoupled from the View layer. It processes data and returns a result.
    public String authenticate(String username, String password) {
        
        // 1. Check for Employer (Admin) credentials
        if (username.equals("admin") && password.equals("adminpass")) {
            return "ADMIN";
        }

        // 2. Check for Employee credentials
        // WHY: We construct the expected file name using the provided username (which acts as the empID).
        String fileName = username + "_info.dat";
        File employeeFile = new File(fileName);

        if (employeeFile.exists()) {
            try {
                // Load the serialized object
                Employee emp = FileStorageUtil.loadData(fileName);
                
                // Verify the password matches the one stored in the Employee object
                if (emp.getEmpPass().equals(password)) {
                    return "EMPLOYEE";
                } else {
                    return "INVALID_PASSWORD";
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "ERROR";
            }
        }

        // If not admin and file doesn't exist
        return "USER_NOT_FOUND";
    }
}
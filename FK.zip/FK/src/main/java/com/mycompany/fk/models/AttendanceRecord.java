package com.mycompany.fk.models;
import java.io.Serializable;

public class AttendanceRecord implements Serializable {
    private static final long serialVersionUID = 1L;
    private String day;
    private String timeIn;
    private String timeOut;
    private boolean isAbsent;
    private boolean isLeaveRequested;
    private boolean isLeaveApproved;

    public AttendanceRecord(String day) {
        this.day = day;
        this.timeIn = "00:00";
        this.timeOut = "00:00";
    }
    // Getters and Setters
    public String getDay() { return day; }
    public String getTimeIn() { return timeIn; }
    public void setTimeIn(String timeIn) { this.timeIn = timeIn; }
    public String getTimeOut() { return timeOut; }
    public void setTimeOut(String timeOut) { this.timeOut = timeOut; }
    public boolean isAbsent() { return isAbsent; }
    public void setAbsent(boolean absent) { isAbsent = absent; }
    public boolean isLeaveRequested() { return isLeaveRequested; }
    public void setLeaveRequested(boolean leaveRequested) { isLeaveRequested = leaveRequested; }
    public boolean isLeaveApproved() { return isLeaveApproved; }
    public void setLeaveApproved(boolean leaveApproved) { isLeaveApproved = leaveApproved; }
}
package com.mycompany.fk.services;
import com.mycompany.fk.models.EmployeeData;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileIOService {
    private static final String FILE_PATH = "employee_database.dat";

    public static void saveEmployees(List<EmployeeData> employees) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(employees);
        } catch (IOException e) {
            System.err.println("Error saving data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static List<EmployeeData> loadEmployees() {
        File file = new File(FILE_PATH);
        if (!file.exists()) return new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<EmployeeData>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}

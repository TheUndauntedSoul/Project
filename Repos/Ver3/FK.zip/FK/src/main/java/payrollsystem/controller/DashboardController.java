package payrollsystem.controller;

import payrollsystem.model.*;
import payrollsystem.utils.PayrollCalculator;
import payrollsystem.view.DashboardView; // Adjust import if your view is in payrollsystem.view

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.DateTimeException;

public class DashboardController {
    
    private DashboardView view;
    private Employee loggedInUser;
    private boolean isAdmin;

    // State variables migrated from View
    private boolean isUpdatingTable = false;
    private double totalLateMinsGlobal = 0;
    private double totalUTMinsGlobal = 0;

    public DashboardController(DashboardView view, Employee loggedInUser, boolean isAdmin) {
        this.view = view;
        this.loggedInUser = loggedInUser;
        this.isAdmin = isAdmin;
        
        initView();
        initController();
    }

    private void initView() {
        switchPanel(true, false, false);

        if (!isAdmin && loggedInUser != null) {
            view.getTxtName().setText(loggedInUser.getName());
            view.getTxtName().setForeground(java.awt.Color.BLACK);
            view.getTxtName().setEditable(false);
            
            view.getTxtId().setText(loggedInUser.getId());
            view.getTxtId().setForeground(java.awt.Color.BLACK);
            view.getTxtId().setEditable(false);
            
            view.getTxtSalary().setText(String.valueOf(loggedInUser.getSalaryRate()));
            view.getTxtSalary().setForeground(java.awt.Color.BLACK);
            view.getTxtSalary().setEditable(false);
            
            view.getCmbType().setSelectedItem(loggedInUser.getEmployeeType());
            view.getCmbType().setEnabled(false);
            
            view.getCmbCutoff().setSelectedItem(loggedInUser.getCutoffPeriod());
            view.getCmbCutoff().setEnabled(false);
        }
        
        // Initial Table population
        refreshAttendanceTable();
    }

    private void initController() {
        // 1. Navigation Wiring
        view.getBtnEmployeeInfo().addActionListener(e -> switchPanel(true, false, false));
        view.getBtnTimeTable().addActionListener(e -> switchPanel(false, true, false));
        view.getBtnPayslip().addActionListener(e -> switchPanel(false, false, true));

        // 2. ComboBox & Month Chooser Triggers
        view.getCmbType().addActionListener(e -> refreshAttendanceTable());
        view.getCmbCutoff().addActionListener(e -> refreshAttendanceTable());
        view.getMonthChooser().addPropertyChangeListener("month", e -> refreshAttendanceTable());

        // 3. Table Model Listener (Time Travel, Format, Mutex)
        view.getTableAttendance().getModel().addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                handleTableChange(e);
            }
        });

        // 4. Submit Button (Payslip Generation)
        view.getBtnSubmitTable().addActionListener(e -> generatePayslip());
        initValidationListeners();
    }

    private void switchPanel(boolean lay1, boolean lay2, boolean lay3) {
        view.getLay1().setVisible(lay1);
        view.getLay2().setVisible(lay2);
        view.getLay3().setVisible(lay3);
    }
    
    private void initValidationListeners() {
        // 1. Employee ID Validation (XXXX-XXXX-XX)
        view.getTxtId().addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                String id = view.getTxtId().getText().trim();
                if (!id.equals("(xxxx-xxxx-xx)") && !id.isEmpty() && !id.matches("\\d{4}-\\d{4}-\\d{2}")) {
                    JOptionPane.showMessageDialog(view.getLay1(), "Format Error: ID must be XXXX-XXXX-XX");
                    view.getTxtId().requestFocusInWindow();
                }
            }
        });

        // Move to salary field after pressing Enter on ID
        view.getTxtId().addActionListener(e -> view.getTxtSalary().requestFocusInWindow());

        // 2. Monthly Salary Validation
        view.getTxtSalary().addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                String input = view.getTxtSalary().getText().replace(",", "").trim();
                if (!input.equals("Enter Salary...") && !input.isEmpty()) {
                    try {
                        double val = Double.parseDouble(input);
                        if (val <= 0) throw new Exception();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(view.getLay1(), "Invalid Salary: Please enter a positive number.");
                        view.getTxtSalary().requestFocusInWindow();
                    }
                }
            }
        });

        // Move to loans field after pressing Enter on Salary
        view.getTxtSalary().addActionListener(e -> view.getTxtLoans().requestFocusInWindow());

        // 3. Loans Validation
        view.getTxtLoans().addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                String input = view.getTxtLoans().getText().trim();
                if (!input.isEmpty() && !input.equals("0")) {
                    try {
                        Double.parseDouble(input);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(view.getLay1(), "Invalid Loan: Please enter a numeric value.");
                        view.getTxtLoans().requestFocusInWindow();
                    }
                }
            }
        });
    }
        
    // --- PHASE 4 MATH & LOGIC MIGRATION ---

    private void refreshAttendanceTable() {
        DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();
        model.setRowCount(0);

        String empType = view.getCmbType().getSelectedItem().toString();
        boolean canHaveLeave = empType.equalsIgnoreCase("Regular") || empType.equalsIgnoreCase("Probationary");

        // Hardcoding year 2026 as per original logic, though ideally dynamic
        int year = 2026; 
        int month = view.getMonthChooser().getMonth() + 1; 
        int startDay = (view.getCmbCutoff().getSelectedIndex() == 0) ? 1 : 16;
        int endDay = (view.getCmbCutoff().getSelectedIndex() == 0) ? 15 : 30;

        for (int i = startDay; i <= endDay; i++) {
            try {
                LocalDate date = LocalDate.of(year, month, i);
                DayOfWeek dow = date.getDayOfWeek();
                String dateLabel = i + " (" + dow.toString().substring(0, 3) + ")";
                
                if (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY) {
                    model.addRow(new Object[]{dateLabel, "REST DAY", "REST DAY", false, false});
                } else {
                    model.addRow(new Object[]{dateLabel, "08:00", "17:00", false, false});
                }
            } catch (DateTimeException ex) {
                break; // End of month reached (e.g., Feb 30th)
            }
        }
        updateAttendanceLabels();
    }

    private void handleTableChange(TableModelEvent e) {
        if (isUpdatingTable || e.getType() != TableModelEvent.UPDATE) return;

        int row = e.getFirstRow();
        int col = e.getColumn();
        if (row < 0 || col < 0) return;

        DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();

        if (col == 1 || col == 2) {
            String inStr = model.getValueAt(row, 1).toString();
            String outStr = model.getValueAt(row, 2).toString();
            String input = model.getValueAt(row, col).toString();

            if (!input.equals("REST DAY") && !input.equals("ABSENT") && !input.equals("LEAVE")) {
                if (!isValidTime(input)) {
                    isUpdatingTable = true;
                    JOptionPane.showMessageDialog(null, "Invalid Format! Use HH:mm (e.g. 08:00).");
                    model.setValueAt(col == 1 ? "08:00" : "17:00", row, col);
                    isUpdatingTable = false;
                    return;
                }
            }

            if (isValidTime(inStr) && isValidTime(outStr)) {
                double inMins = timeToMinutes(inStr);
                double outMins = timeToMinutes(outStr);

                if (outMins < inMins) {
                    isUpdatingTable = true;
                    JOptionPane.showMessageDialog(null, "Logical Error: Time Out cannot be earlier than Time In!", "Time Travel Detected", JOptionPane.ERROR_MESSAGE);
                    model.setValueAt(col == 1 ? "08:00" : "17:00", row, col);
                    isUpdatingTable = false;
                    return;
                }
            }
        }

        isUpdatingTable = true;
        try {
            if (col == 3) {
                boolean isAbsent = (boolean) model.getValueAt(row, 3);
                if (isAbsent) model.setValueAt(false, row, 4);
            } else if (col == 4) {
                boolean isLeave = (boolean) model.getValueAt(row, 4);
                if (isLeave) model.setValueAt(false, row, 3);
            }
            updateAttendanceLabels();
        } finally {
            isUpdatingTable = false;
        }
    }

    private void updateAttendanceLabels() {
        double totalRegHours = 0;
        double totalOTHours = 0;
        totalLateMinsGlobal = 0; 
        totalUTMinsGlobal = 0;   
        int leaves = 0, absences = 0;

        DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();

        for (int i = 0; i < model.getRowCount(); i++) {
            Object inObj = model.getValueAt(i, 1);
            Object outObj = model.getValueAt(i, 2);
            boolean isAbs = (boolean) model.getValueAt(i, 3);
            boolean isLeave = (boolean) model.getValueAt(i, 4);
            
            if (isAbs) { 
                absences++; 
            } else if (isLeave) { 
                leaves++; 
            } else if (inObj != null && outObj != null) {
                String inStr = inObj.toString();
                String outStr = outObj.toString();
            
                if (!inStr.equals("REST DAY") && isValidTime(inStr) && isValidTime(outStr)) {
                    double inMins = timeToMinutes(inStr);
                    double outMins = timeToMinutes(outStr);

                    if (inMins > 480) totalLateMinsGlobal += (inMins - 480);
                    if (outMins < 1020) totalUTMinsGlobal += (1020 - outMins);

                    double effectiveInMins = Math.max(inMins, 480); 
                    double effectiveOutMins = Math.min(outMins, 1020);

                    double regWorkMins = effectiveOutMins - effectiveInMins;
                    if (regWorkMins > 300) regWorkMins -= 60; // Lunch break
                    totalRegHours += Math.max(0, regWorkMins / 60.0);

                    if (outMins > 1020) {
                        double otMins = outMins - 1020;
                        totalOTHours += (otMins / 60.0);
                    }
                }
            }
        }

        view.getLblWorkedHours().setText(formatDecimalToTime(totalRegHours)); 
        view.getLblOvertime().setText(formatDecimalToTime(totalOTHours));  
        view.getLblLeaves().setText(String.valueOf(leaves));               
        view.getLblAbsences().setText(String.valueOf(absences));             
    }

    private void generatePayslip() {
        try {
            String id = view.getTxtId().getText().trim();
            String name = view.getTxtName().getText().trim();
            String type = view.getCmbType().getSelectedItem().toString();
            
            // Handle Placeholders / Empty Inputs gracefully
            String salaryRaw = view.getTxtSalary().getText().replace(",", "").trim();
            String loanRaw = view.getTxtLoans().getText().trim();
            if (salaryRaw.contains("Enter Salary") || salaryRaw.isEmpty()) salaryRaw = "0";
            if (loanRaw.isEmpty()) loanRaw = "0";

            double salaryInput = Double.parseDouble(salaryRaw);
            double loans = Double.parseDouble(loanRaw);

            int activeWorkDays = 0;
            DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();
            for (int i = 0; i < model.getRowCount(); i++) {
                Object dayVal = model.getValueAt(i, 0);
                if (dayVal != null && !dayVal.toString().trim().isEmpty()) {
                    String dayText = dayVal.toString().toUpperCase();
                    if (!dayText.contains("(SAT)") && !dayText.contains("(SUN)")) activeWorkDays++;
                }
            }

            Employee emp;
            String cutoff = view.getCmbCutoff().getSelectedItem().toString();
            if (type.equalsIgnoreCase("Regular")) {
                emp = new RegularEmployee(name, id, "temp", salaryInput, cutoff);
            } else if (type.equalsIgnoreCase("Probationary")) {
                emp = new ProbationaryEmployee(name, id, "temp", salaryInput, cutoff);
            } else if (type.equalsIgnoreCase("Part-Timer")) {
                emp = new PartTimer(name, id, "temp", salaryInput, cutoff);
            } else {
                emp = new ContractualEmployee(name, id, "temp", salaryInput, cutoff);
            }

            double otHours = timeStringToDecimal(view.getLblOvertime().getText());
            int totalAbs = Integer.parseInt(view.getLblAbsences().getText());
            double maxPeriodHrs = activeWorkDays * 8.0;
            double lateHrs = totalLateMinsGlobal / 60.0;
            double utHrs = totalUTMinsGlobal / 60.0;
            double absHrs = totalAbs * 8.0;
            double actualWorkedHours = maxPeriodHrs - (lateHrs + utHrs + absHrs);

            double basePay = emp.calculateBasePay(actualWorkedHours); 
            double deductionRate = (type.equalsIgnoreCase("Part-Timer")) ? salaryInput : basePay / maxPeriodHrs;
            double regularPay = actualWorkedHours * deductionRate; 

            double standardHourlyRate = (salaryInput / 20) / 8; 
            double otPay = otHours * (standardHourlyRate * 1.25);
            double grossPay = regularPay + otPay;

            double statutoryBasis = (type.equalsIgnoreCase("Part-Timer")) ? grossPay : salaryInput;

            double sss = PayrollCalculator.getSSSEmployeeShare(statutoryBasis);
            double ph = PayrollCalculator.getPhilHealthShare(statutoryBasis);
            double pi = PayrollCalculator.getPagIBIGShare();

            double taxableIncome = grossPay - (sss + ph + pi);
            double tax = PayrollCalculator.calculateTax(taxableIncome);

            double totalDeductions = sss + ph + pi + tax + loans;
            double netPay = grossPay - totalDeductions;

            double lateDeductionVal = lateHrs * deductionRate;
            double utDeductionVal = utHrs * deductionRate;
            double absDeductionVal = absHrs * deductionRate;
            double totalTimeDeductions = lateDeductionVal + utDeductionVal + absDeductionVal;

            view.getTxtPayslip().setText(String.format(
                "       NATIONAL UNIVERSITY DASMARIÑAS\n" +
                "       Official Employee Payroll Slip\n" +
                "==============================================\n" +
                "NAME: %s\nID NO: %s\nSTATUS: %s\n" +
                "----------------------------------------------\n" +
                "I. ATTENDANCE & EARNINGS BREAKDOWN\n" +
                "  Max Period Hours:       %10.2f\n" +
                "  Gross Period Base:      PHP %,10.2f\n" + 
                "\n" +
                "  TIME DEDUCTIONS:\n" +
                "    Lateness (%5.2f hrs): PHP %,10.2f\n" +
                "    Undertime (%5.2f hrs):PHP %,10.2f\n" +
                "    Absences (%5.2f hrs): PHP %,10.2f\n" +
                "    TOTAL TIME LOSS:     (PHP %,10.2f)\n" +
                "----------------------------------------------\n" +
                "  REGULAR PAY (NET):      PHP %,10.2f\n" +
                "  OVERTIME PAY:           PHP %,10.2f\n" +
                "  TOTAL GROSS EARNINGS:   PHP %,10.2f\n" +
                "----------------------------------------------\n" +
                "II. MANDATORY CONTRIBUTIONS\n" +
                "  SSS Premium:            PHP %,10.2f\n" +
                "  PhilHealth Premium:     PHP %,10.2f\n" +
                "  Pag-IBIG Fund:          PHP %,10.2f\n" +
                "  TOTAL MANDATORY:        PHP %,10.2f\n" +
                "----------------------------------------------\n" +
                "III. TAX & OTHER DEDUCTIONS\n" +
                "  Withholding Tax:        PHP %,10.2f\n" +
                "  Personal Loans:         PHP %,10.2f\n" +
                "----------------------------------------------\n" +
                "TOTAL DEDUCTIONS:         PHP %,10.2f\n" +
                "NET TAKE-HOME PAY:        PHP %,10.2f\n" +
                "==============================================\n",
                name, id, type, 
                maxPeriodHrs, basePay,
                lateHrs, lateDeductionVal,
                utHrs, utDeductionVal,
                absHrs, absDeductionVal,
                totalTimeDeductions,
                regularPay, otPay, grossPay,
                sss, ph, pi, (sss + ph + pi),
                tax, loans, totalDeductions, 
                netPay
            ));

            switchPanel(false, false, true);
            view.getTxtPayslip().setCaretPosition(0);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Input Error: Ensure Salary and Loans are valid numbers.");
        }
    }

    // --- UTILITY METHODS ---
    private boolean isValidTime(String time) {
        String timePattern = "([01]?[0-9]|2[0-9]):[0-5][0-9]";
        return time != null && time.matches(timePattern);
    }
    
    private double timeToMinutes(String time) {
        String[] parts = time.split(":");
        return Double.parseDouble(parts[0]) * 60 + Double.parseDouble(parts[1]);
    }   
    
    private String formatDecimalToTime(double decimalHours) {
        int h = (int) decimalHours;
        int m = (int) Math.round((decimalHours - h) * 60);
        return String.format("%02d:%02d", h, m);
    }
    
    private double timeStringToDecimal(String timeStr) {
        try {
            String[] parts = timeStr.trim().split(":");
            return Double.parseDouble(parts[0]) + (Double.parseDouble(parts[1]) / 60.0);
        } catch (NumberFormatException e) { return 0.0; }
    }
}
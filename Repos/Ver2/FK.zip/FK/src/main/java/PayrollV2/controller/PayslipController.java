package PayrollV2.controller;

import PayrollV2.model.Employee;
import PayrollV2.model.DailyTimeRecord;
import PayrollV2.model.Payslip;
import java.time.LocalDate;
import java.time.DayOfWeek;
import java.util.List;

public class PayslipController {

    public Payslip generatePayslip(Employee emp, List<DailyTimeRecord> records) {
        double totalRegHours = 0;
        double totalOTHours = 0;
        int activeWorkDays = 0;

        // 1. CALCULATE HOURS WORKED
        for (DailyTimeRecord rec : records) {
            LocalDate date = LocalDate.parse(rec.getDate());
            
            // Skip weekends
            if (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
                continue;
            }
            activeWorkDays++;

            // If leave is approved, grant 8 hours of paid regular time
            if (rec.getLeaveStatus().equals("APPROVED")) {
                totalRegHours += 8.0;
                continue;
            }

            // Skip unlogged/absent days
            if (rec.getTimeIn().equals("Not Logged") || rec.getTimeOut().equals("Not Logged") || rec.getTimeIn().equals("ON LEAVE")) {
                continue;
            }

            // Time math (Adapted from V1 PANE1 logic)
            double inMins = timeToMinutes(rec.getTimeIn());
            double outMins = timeToMinutes(rec.getTimeOut());

            // Strict capping (08:00 to 17:00)
            double effectiveIn = Math.max(inMins, 480); 
            double effectiveOut = Math.min(outMins, 1020);
            
            double regMins = effectiveOut - effectiveIn;
            if (regMins > 300) regMins -= 60; // 1 Hour Lunch break deduction
            totalRegHours += Math.max(0, regMins / 60.0);

            // Overtime logic (After 17:00)
            if (outMins > 1020) {
                totalOTHours += (outMins - 1020) / 60.0;
            }
        }

        // 2. CALCULATE EARNINGS
        double grossPay = 0;
        double statutoryBasis = 0;

        if (emp.getEmpType().equalsIgnoreCase("Part-Timer")) {
            // Part-timer gets paid purely by the hour
            double regPay = totalRegHours * emp.getEmpHourSalary();
            double otPay = totalOTHours * (emp.getEmpHourSalary() * 1.25);
            grossPay = regPay + otPay;
            statutoryBasis = grossPay; // Deductions based on actual earnings
        } else {
            // Regular/Probationary logic from V1
            double maxPeriodHrs = activeWorkDays * 8.0;
            double biMonthlySalary = emp.getEmpMonthSalary() / 2;
            double deductionRate = biMonthlySalary / maxPeriodHrs;
            
            double regPay = totalRegHours * deductionRate;
            double standardHourlyRate = (emp.getEmpMonthSalary() / 20) / 8; 
            double otPay = totalOTHours * (standardHourlyRate * 1.25);
            
            grossPay = regPay + otPay;
            statutoryBasis = emp.getEmpMonthSalary(); // Deductions based on base monthly rate
        }

        // 3. CALCULATE V1 DEDUCTIONS (Bi-monthly rates)
        // SSS: Min 5000, Max 35000, 5% Employee Share halved
        double sscapped = Math.max(5000, Math.min(statutoryBasis, 35000));
        double sss = (sscapped * 0.05) / 2;
        
        // PhilHealth: 2.5% Employee Share halved
        double philhealth = (statutoryBasis * 0.025) / 2;
        
        // Pag-IBIG: Fixed 200 total -> 100 EE Share
        double pagibig = 100.0;

        // Tax Calculation (V1 BIR Table)
        double taxableIncome = grossPay - (sss + philhealth + pagibig);
        double tax = calculateTax(taxableIncome);

        double totalDeductions = sss + philhealth + pagibig + tax + emp.getEmpLoan();
        double netPay = grossPay - totalDeductions;

        // 4. RETURN FINAL PAYSLIP
        return new Payslip(totalRegHours, totalOTHours, grossPay, sss, philhealth, pagibig, tax, emp.getEmpLoan(), totalDeductions, netPay);
    }

    // Helper: Convert HH:mm to minutes
    private double timeToMinutes(String time) {
        String[] parts = time.split(":");
        return Double.parseDouble(parts[0]) * 60 + Double.parseDouble(parts[1]);
    }

    // Helper: V1 Tax Table
    private double calculateTax(double taxableIncome) {
        if (taxableIncome <= 10417) return 0;
        else if (taxableIncome <= 16666) return (taxableIncome - 10417) * 0.15;
        else if (taxableIncome <= 33332) return 937.50 + ((taxableIncome - 16667) * 0.20);
        else if (taxableIncome <= 83332) return 4270.70 + ((taxableIncome - 33333) * 0.25);
        else if (taxableIncome <= 333332) return 16770.70 + ((taxableIncome - 83333) * 0.30);
        else return 91770.70 + ((taxableIncome - 333333) * 0.35);
    }
}

package PayrollV2.util;

import java.io.*;

public class FileStorageUtil {

    // We use a generic type <T> that extends Serializable.
    // WHY: This ensures we can pass an Employee object, a List of Employees, or a TimeRecord object 
    // into this exact same method without having to write separate save methods for each class.
    public static <T extends Serializable> void saveData(T objectToSave, String filePath) throws IOException {
        
        // WHY: We use a "try-with-resources" block (the parentheses after 'try'). 
        // This guarantees that the file streams are automatically closed even if an error occurs, 
        // preventing file corruption or locking the .dat file.
        try (FileOutputStream fileOut = new FileOutputStream(filePath);
             ObjectOutputStream objectOut = new ObjectOutputStream(fileOut)) {
             
            objectOut.writeObject(objectToSave);
        }
    }

    // Generic method to read data back from the .dat files.
    @SuppressWarnings("unchecked")
    public static <T extends Serializable> T loadData(String filePath) throws IOException, ClassNotFoundException {
        
        try (FileInputStream fileIn = new FileInputStream(filePath);
             ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {
             
            // WHY: readObject() returns a generic Object. We cast it to (T) so the calling 
            // class receives the specific type (like Employee) it is expecting.
            return (T) objectIn.readObject();
        }
    }
}

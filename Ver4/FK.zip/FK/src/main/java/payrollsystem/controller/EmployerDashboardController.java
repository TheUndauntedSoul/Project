package payrollsystem.controller;

import payrollsystem.model.*;
import payrollsystem.view.*;
import payrollsystem.utils.*;


import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.DateTimeException;
import java.util.List;

public class EmployerDashboardController {
    
    private EmployerDashboardView view;
    private Employee loggedInUser;
    private boolean isAdmin;
    
    // Database State
    private List<Employee> employeeDatabase;
    private Employee currentViewedEmployee; // The employee the Admin is currently looking at

    private boolean isUpdatingTable = false;

    public EmployerDashboardController(EmployerDashboardView view, Employee loggedInUser, boolean isAdmin) {
        this.view = view;
        this.loggedInUser = loggedInUser;
        this.isAdmin = isAdmin;
        this.employeeDatabase = FileStorageManager.loadEmployees();
        
        initView();
        initController();
    }

    private void initView() {
        switchPanel(true, false, false);

        if (!isAdmin) {
            // Lock UI for regular employees
            view.getTxtName().setText(loggedInUser.getName());
            view.getTxtName().setEditable(false);
            view.getTxtId().setText(loggedInUser.getId());
            view.getTxtId().setEditable(false);
            view.getTxtSalary().setText(String.valueOf(loggedInUser.getSalaryRate()));
            view.getTxtSalary().setEditable(false);
            view.getCmbType().setSelectedItem(loggedInUser.getEmployeeType());
            view.getCmbType().setEnabled(false);
            view.getCmbCutoff().setSelectedItem(loggedInUser.getCutoffPeriod());
            view.getCmbCutoff().setEnabled(false);
            
            // Hide Admin controls
            view.getBtnCreateEmployee().setVisible(false);
            view.getBtnUpdateEmployee().setVisible(false);
            view.getBtnDeleteEmployee().setVisible(false);
            view.getTxtPassword().setVisible(false);
            
            currentViewedEmployee = loggedInUser;
            refreshAttendanceTable();
        }
    }

    private void initController() {
        // Navigation Wiring
        view.getBtnEmployeeInfo().addActionListener(e -> switchPanel(true, false, false));
        view.getBtnTimeTable().addActionListener(e -> switchPanel(false, true, false));
        view.getBtnPayslip().addActionListener(e -> switchPanel(false, false, true));

        // Dynamic ComboBox Triggers
        view.getCmbType().addActionListener(e -> {
            String type = view.getCmbType().getSelectedItem().toString();
            if (type.equalsIgnoreCase("Part-Timer")) {
                view.getLblSalaryTitle().setText("Hourly Rate:");
            } else {
                view.getLblSalaryTitle().setText("Monthly Salary Rate:");
            }
            refreshAttendanceTable();
        });
        
        view.getCmbCutoff().addActionListener(e -> refreshAttendanceTable());
        view.getMonthChooser().addPropertyChangeListener("month", e -> refreshAttendanceTable());

        // Lay 1: Admin Controls (Create, Update, Delete)
        if (isAdmin) {
            view.getBtnCreateEmployee().addActionListener(e -> createEmployee());
            view.getBtnUpdateEmployee().addActionListener(e -> updateEmployee());
            view.getBtnDeleteEmployee().addActionListener(e -> deleteEmployee());
            // --- NAVIGATION CONTROLS ---
            view.getBtnLogout().addActionListener(e -> logout());
        }

        // Lay 2: Time Table Controls
        view.getBtnSearchLay2().addActionListener(e -> searchEmployee(view.getTxtSearchIdLay2().getText().trim(), 2));
        
        // --- LAY 2 CONTROLS (Smart Table & Actions) ---
        view.getTableAttendance().getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                handleRowSelection(); // Triggers the Auto-Detect
            }
        });

        view.getBtnApplyLeave().addActionListener(e -> applyLeaveStatus());
        view.getBtnApplyOt().addActionListener(e -> applyOtStatus());
        view.getBtnSetDayType().addActionListener(e -> applyDayType());
        
        view.getTableAttendance().getModel().addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) { handleTableChange(e); }
        });

        // Lay 3: Payslip Controls
        view.getBtnSearchLay3().addActionListener(e -> searchEmployee(view.getTxtSearchIdLay3().getText().trim(), 3));
        view.getBtnGeneratePayslip().addActionListener(e -> {
            // Check if the Admin has actually loaded an employee profile first
            if (currentViewedEmployee != null) {
                generatePayslip(currentViewedEmployee); // Pass the employee into the method!
            } else {
                javax.swing.JOptionPane.showMessageDialog(view, 
                    "Please search for and load an employee profile first.", 
                    "No Employee Selected", 
                    javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        });
        view.getBtnReleasePayslip().addActionListener(e -> releasePayslip());

        // Initialize strict field validators
        initValidationListeners();
    }

    private void initValidationListeners() {
        // --- Lay 1 (Create/Update) Validators ---
        // ID Validation (Format check + Auto-shift focus on Enter)
        view.getTxtId().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validateIdField(); }
        });
        view.getTxtId().addActionListener(e -> { 
            if (validateIdField()) view.getTxtPassword().requestFocusInWindow(); 
        });

        // Password Validation (Cannot be empty placeholder)
        view.getTxtPassword().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validatePasswordField(); }
        });
        view.getTxtPassword().addActionListener(e -> { 
            if (validatePasswordField()) view.getTxtSalary().requestFocusInWindow(); 
        });

        // Salary Validation (Must be a positive number)
        view.getTxtSalary().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validateSalaryField(); }
        });
        view.getTxtSalary().addActionListener(e -> { 
            if (validateSalaryField()) view.getTxtLoans().requestFocusInWindow(); 
        });

        // --- Lay 2 & Lay 3 (Search) Validators ---
        // Lay 2 Search Validation
        view.getTxtSearchIdLay2().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validateSearchIdField(view.getTxtSearchIdLay2()); }
        });
        view.getTxtSearchIdLay2().addActionListener(e -> { 
            if (validateSearchIdField(view.getTxtSearchIdLay2())) view.getBtnSearchLay2().doClick(); 
        });

        // Lay 3 Search Validation
        view.getTxtSearchIdLay3().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validateSearchIdField(view.getTxtSearchIdLay3()); }
        });
        view.getTxtSearchIdLay3().addActionListener(e -> { 
            if (validateSearchIdField(view.getTxtSearchIdLay3())) view.getBtnSearchLay3().doClick(); 
        });
    }

    // ==========================================
    // STRICT VALIDATOR HELPERS
    // ==========================================
    
    private boolean validateIdField() {
        String id = view.getTxtId().getText().trim();
        if (id.equals("(xxxx-xxxx-xx)") || id.isEmpty()) return false; 
        if (!id.matches("\\d{4}-\\d{4}-\\d{2}")) {
            JOptionPane.showMessageDialog(view.getLay1(), "Format Error: ID must be XXXX-XXXX-XX", "Validation Error", JOptionPane.ERROR_MESSAGE);
            view.getTxtId().requestFocusInWindow();
            return false;
        }
        return true;
    }

    private boolean validatePasswordField() {
        String pass = view.getTxtPassword().getText().trim();
        if (pass.equals("Enter Employee Password...") || pass.isEmpty()) return false;
        if (pass.length() < 4) {
            JOptionPane.showMessageDialog(view.getLay1(), "Password must be at least 4 characters.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            view.getTxtPassword().requestFocusInWindow();
            return false;
        }
        return true;
    }

    private boolean validateSalaryField() {
        String input = view.getTxtSalary().getText().replace(",", "").trim();
        if (input.equals("Enter Salary...") || input.isEmpty()) return false;
        try {
            double val = Double.parseDouble(input);
            if (val <= 0) throw new Exception();
            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view.getLay1(), "Invalid Input: Please enter a positive numeric value for salary/rate.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            view.getTxtSalary().requestFocusInWindow();
            return false;
        }
    }

    private boolean validateSearchIdField(javax.swing.JTextField searchField) {
        String id = searchField.getText().trim();
        
        // Ignore it if it's empty, or if it matches EITHER of the ID placeholders
        if (id.isEmpty() || id.equalsIgnoreCase("(xxxx-xxxx-xx)") || id.equalsIgnoreCase("Enter ID to Search...")) {
            return true; 
        }
        
        if (!id.matches("\\d{4}-\\d{4}-\\d{2}")) {
            // Use the main view for the popup so it doesn't get stuck behind panels
            JOptionPane.showMessageDialog(view, "Format Error: Search ID must be XXXX-XXXX-XX", "Validation Error", JOptionPane.ERROR_MESSAGE);
            searchField.requestFocusInWindow();
            return false;
        }
        return true;
    }

    private Employee findEmployeeById(String id) {
        for (Employee emp : employeeDatabase) {
            if (emp.getId().equals(id)) return emp;
        }
        return null;
    }

    private void switchPanel(boolean lay1, boolean lay2, boolean lay3) {
        view.getLay1().setVisible(lay1);
        view.getLay2().setVisible(lay2);
        view.getLay3().setVisible(lay3);
    }

    // --- LAY 1: CRUD OPERATIONS ---

    private void createEmployee() {
        // 1. Force final validation pass
        if (!validateIdField() || !validatePasswordField() || !validateSalaryField()) {
            JOptionPane.showMessageDialog(view, "Please ensure all fields contain valid data before creating.");
            return;
        }

        String id = view.getTxtId().getText().trim();
        
        // 2. Strict Duplicate Check
        if (findEmployeeById(id) != null) {
            JOptionPane.showMessageDialog(view, "Creation Failed: Employee ID '" + id + "' already exists! Use the Update button instead.", "Duplicate ID", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String name = view.getTxtName().getText().trim();
            if (name.equals("Enter Your Full Name...") || name.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Please enter a valid Name."); return;
            }

            String pass = view.getTxtPassword().getText().trim();
            String type = view.getCmbType().getSelectedItem().toString();
            String cutoff = view.getCmbCutoff().getSelectedItem().toString();
            double salary = Double.parseDouble(view.getTxtSalary().getText().replace(",", "").trim());

            Employee newEmp;
            if (type.equalsIgnoreCase("Regular")) newEmp = new RegularEmployee(name, id, pass, salary, cutoff);
            else if (type.equalsIgnoreCase("Probationary")) newEmp = new ProbationaryEmployee(name, id, pass, salary, cutoff);
            else if (type.equalsIgnoreCase("Part-Timer")) newEmp = new PartTimer(name, id, pass, salary, cutoff);
            else newEmp = new ContractualEmployee(name, id, pass, salary, cutoff);

            employeeDatabase.add(newEmp);
            payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
            JOptionPane.showMessageDialog(view, "Employee " + name + " Created Successfully!");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "A system error occurred during creation.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateEmployee() {
        String id = view.getTxtId().getText().trim();
        
        // 1. Strict Existence Check
        Employee targetEmp = findEmployeeById(id);
        if (targetEmp == null) {
            JOptionPane.showMessageDialog(view, "Update Failed: Cannot find an employee with ID '" + id + "'.", "Not Found", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. Validation
        if (!validatePasswordField() || !validateSalaryField()) {
            JOptionPane.showMessageDialog(view, "Please ensure updated fields contain valid data.");
            return;
        }

        try {
            // Standard field updates
            targetEmp.setName(view.getTxtName().getText().trim());
            targetEmp.setPassword(view.getTxtPassword().getText().trim());
            targetEmp.setEmployeeType(view.getCmbType().getSelectedItem().toString());
            targetEmp.setCutoffPeriod(view.getCmbCutoff().getSelectedItem().toString());
            targetEmp.setSalaryRate(Double.parseDouble(view.getTxtSalary().getText().replace(",", "").trim()));
            
            // --- LOAN CAPTURE LOGIC ---
            // Grabs text, cleans it, and updates the Employee object
            String loanStr = view.getTxtLoans().getText().replaceAll("[^\\d.]", ""); 
            double updatedLoan = loanStr.isEmpty() ? 0.0 : Double.parseDouble(loanStr);
            targetEmp.setLoanBalance(updatedLoan);
            // --------------------------

            FileStorageManager.saveEmployees(employeeDatabase);
            JOptionPane.showMessageDialog(view, "Employee " + targetEmp.getName() + " Updated Successfully!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Invalid Input data detected during update: " + ex.getMessage());
        }
    }

    private void deleteEmployee() {
        String id = view.getTxtId().getText().trim();
        
        // 1. Strict Existence Check
        Employee targetEmp = findEmployeeById(id);
        if (targetEmp == null) {
            JOptionPane.showMessageDialog(view, "Delete Failed: Cannot find an employee with ID '" + id + "'.", "Not Found", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. Confirmation
        int confirm = JOptionPane.showConfirmDialog(view, "WARNING: Are you sure you want to permanently delete " + targetEmp.getName() + " (" + id + ")?", "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            employeeDatabase.remove(targetEmp);
            payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
            JOptionPane.showMessageDialog(view, "Employee record permanently deleted.");
            
            // Clear fields after delete
            view.getTxtId().setText("(xxxx-xxxx-xx)");
            view.getTxtName().setText("Enter Your Full Name...");
            view.getTxtPassword().setText("Enter Employee Password...");
            view.getTxtSalary().setText("Enter Salary...");
        }
    }

    // --- SEARCH UTILITY ---

    private void searchEmployee(String searchId, int layNumber) {
        if (searchId.isEmpty() || searchId.equals("(xxxx-xxxx-xx)")) return;
        
        if (!searchId.matches("\\d{4}-\\d{4}-\\d{2}")) {
            JOptionPane.showMessageDialog(view, "Format Error: Search ID must be XXXX-XXXX-XX", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        for (Employee emp : employeeDatabase) {
            if (emp.getId().equals(searchId)) {
                currentViewedEmployee = emp;
                
                // Populate Lay 1
                view.getTxtId().setText(emp.getId());
                view.getTxtName().setText(emp.getName());
                view.getTxtPassword().setText(emp.getPassword());
                view.getTxtSalary().setText(String.valueOf(emp.getSalaryRate()));
                view.getCmbType().setSelectedItem(emp.getEmployeeType());
                view.getCmbCutoff().setSelectedItem(emp.getCutoffPeriod());
                
                // --- LOAD LOAN DATA ---
                // Displays the database value in the Admin's loan text field
                view.getTxtLoans().setText(String.valueOf(emp.getLoanBalance()));
                // ----------------------

                if (layNumber == 2) refreshAttendanceTable();
                if (layNumber == 3) JOptionPane.showMessageDialog(view, "Loaded " + emp.getName() + " for Payslip Generation.");
                return;
            }
        }
        JOptionPane.showMessageDialog(view, "Employee not found in database.");
    }

    // --- LAY 2: TABLE & LEAVE MANAGEMENT ---

    private void refreshAttendanceTable() {
        if (currentViewedEmployee == null) return;

        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) view.getTableAttendance().getModel();
        model.setRowCount(0);

        // 1. Determine Cutoff Dates based on computer time and Employee settings
        int year = java.time.LocalDate.now().getYear(); 
        int month = java.time.LocalDate.now().getMonthValue(); 
        
        String cutoff = currentViewedEmployee.getCutoffPeriod();
        int startDay = (cutoff != null && cutoff.startsWith("16th")) ? 16 : 1;
        // Smart end day handles February and 31-day months perfectly
        int endDay = (startDay == 1) ? 15 : java.time.YearMonth.of(year, month).lengthOfMonth();

        // 2. Loop through every single day of the cutoff
        for (int i = startDay; i <= endDay; i++) {
            java.time.LocalDate date = java.time.LocalDate.of(year, month, i);
            
            // Search to see if the employee actually has a record for this date
            payrollsystem.model.DailyTimeRecord matchingDtr = getDtrByDate(date);

            String dayStr = date.toString();
            
            if (matchingDtr != null) {
                // Display the actual record
                String tIn = matchingDtr.getTimeIn() != null ? matchingDtr.getTimeIn().toString() : "--";
                String tOut = matchingDtr.getTimeOut() != null ? matchingDtr.getTimeOut().toString() : "--";
                
                String leaveStr = matchingDtr.getStatus().contains("LEAVE") ? matchingDtr.getStatus() : "No Leave";
                String otStr = matchingDtr.isOtApproved() ? "OT Approved" : "No OT";
                String combinedStatus = "(" + leaveStr + ", " + otStr + ")";
                
                String dayType = "Regular";
                if (matchingDtr.isRegularHoliday()) dayType = "Regular Holiday";
                else if (matchingDtr.isSpecialHoliday()) dayType = "Special Non-Working";
                else if (matchingDtr.isRestDay()) dayType = "Rest Day";

                model.addRow(new Object[]{dayStr, tIn, tOut, combinedStatus, dayType});
            } else {
                // Display a blank row. Auto-detect weekends as Rest Days.
                java.time.DayOfWeek dow = date.getDayOfWeek();
                String defaultDayType = (dow == java.time.DayOfWeek.SATURDAY || dow == java.time.DayOfWeek.SUNDAY) ? "Rest Day" : "Regular";
                model.addRow(new Object[]{dayStr, "--", "--", "NO RECORD", defaultDayType});
            }
        }
        
        // Reset action controls so they don't accidentally click a previous state
        view.getCmbLeaveApproval().setEnabled(false);
        view.getBtnApplyLeave().setEnabled(false);
        view.getCmbOtApproval().setEnabled(false);
        view.getBtnApplyOt().setEnabled(false);
        view.getCmbDayType().setEnabled(false);
        view.getBtnSetDayType().setEnabled(false);
    }
    
    // --- HELPER: FIND DTR BY DATE ---
    private payrollsystem.model.DailyTimeRecord getDtrByDate(java.time.LocalDate date) {
        for (payrollsystem.model.DailyTimeRecord dtr : currentViewedEmployee.getDtrRecords()) {
            if (dtr.getDate().equals(date)) return dtr;
        }
        return null;
    }

    private void updateLeaveStatus(String newStatus) {
        if (currentViewedEmployee == null || !isAdmin) return;
        
        int row = view.getTableAttendance().getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(view, "Please select a row in the table first.");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();
        String currentStatus = model.getValueAt(row, 3).toString();
        
        if (currentStatus.equals("LEAVE PENDING")) {
            model.setValueAt(newStatus, row, 3);
            saveTableStateToDatabase();
            JOptionPane.showMessageDialog(view, "Leave " + newStatus);
        } else {
            JOptionPane.showMessageDialog(view, "You can only approve or deny rows marked as LEAVE PENDING.");
        }
    }

    private void handleTableChange(TableModelEvent e) {
        if (isUpdatingTable || e.getType() != TableModelEvent.UPDATE) return;
        
        int row = e.getFirstRow();
        int col = e.getColumn();
        if (row < 0 || col < 0) return;

        DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();
        String timeIn = model.getValueAt(row, 1) != null ? model.getValueAt(row, 1).toString() : "";
        String timeOut = model.getValueAt(row, 2) != null ? model.getValueAt(row, 2).toString() : "";

        isUpdatingTable = true;
        try {
            if (!timeIn.isEmpty() && !timeOut.isEmpty() && !timeIn.equals("REST DAY")) {
                model.setValueAt("PRESENT", row, 3);
            } else if ((timeIn.isEmpty() && !timeOut.isEmpty()) || (!timeIn.isEmpty() && timeOut.isEmpty())) {
                model.setValueAt("INCOMPLETE PUNCH", row, 3);
            } else if (timeIn.isEmpty() && timeOut.isEmpty()) {
                model.setValueAt("ABSENT", row, 3);
            }
        } finally {
            isUpdatingTable = false;
        }
        
        if (!isAdmin) saveTableStateToDatabase(); // Auto-save when employees punch in/out
    }
    
    // --- SMART AUTO-DETECT LOGIC ---
    private void handleRowSelection() {
        int row = view.getTableAttendance().getSelectedRow();
        if (row < 0 || currentViewedEmployee == null) return;

        // Extract Date from the table and find the real DTR
        java.time.LocalDate selectedDate = java.time.LocalDate.parse(view.getTableAttendance().getValueAt(row, 0).toString());
        payrollsystem.model.DailyTimeRecord dtr = getDtrByDate(selectedDate);

        // If there is no record, disable all action buttons. You can't approve time they didn't work!
        if (dtr == null) {
            view.getCmbLeaveApproval().setEnabled(false);
            view.getBtnApplyLeave().setEnabled(false);
            view.getCmbOtApproval().setEnabled(false);
            view.getBtnApplyOt().setEnabled(false);
            
            // Allow them to set Day Type (like declaring a future holiday) even if empty
            view.getCmbDayType().setEnabled(true);
            view.getBtnSetDayType().setEnabled(true);
            return;
        }

        // Enable Day Type for existing records
        view.getCmbDayType().setEnabled(true);
        view.getBtnSetDayType().setEnabled(true);

        // 1. Auto-Detect Leave Request
        boolean isLeaveRequested = dtr.getStatus().contains("LEAVE");
        view.getCmbLeaveApproval().setEnabled(isLeaveRequested);
        view.getBtnApplyLeave().setEnabled(isLeaveRequested);

        // 2. Auto-Detect Overtime (Only if punched out AFTER shift ends)
        boolean hasExcessTime = false;
        if (dtr.getTimeOut() != null) {
            hasExcessTime = dtr.getTimeOut().isAfter(currentViewedEmployee.getShiftEndTime());
        }
        view.getCmbOtApproval().setEnabled(hasExcessTime);
        view.getBtnApplyOt().setEnabled(hasExcessTime);
        
    }

    // --- APPLY BUTTON ACTIONS WITH VALIDATORS ---
    private void applyLeaveStatus() {
        int row = view.getTableAttendance().getSelectedRow();
        if (row < 0) return;

        java.time.LocalDate selectedDate = java.time.LocalDate.parse(view.getTableAttendance().getValueAt(row, 0).toString());
        payrollsystem.model.DailyTimeRecord dtr = getDtrByDate(selectedDate);

        if (dtr == null || !dtr.getStatus().contains("LEAVE")) {
            javax.swing.JOptionPane.showMessageDialog(view, "Validation Error: No Leave requested for this date.", "Action Blocked", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        String choice = view.getCmbLeaveApproval().getSelectedItem().toString();
        if (choice.equals("Approve")) dtr.setStatus("LEAVE APPROVED");
        else if (choice.equals("Deny")) dtr.setStatus("LEAVE DENIED");
        else if (choice.equals("Clear Status")) dtr.setStatus("LEAVE PENDING");
        
        
        
        saveAndRefresh("Leave status updated.");
    }

    private void applyOtStatus() {
        int row = view.getTableAttendance().getSelectedRow();
        if (row < 0) return;

        java.time.LocalDate selectedDate = java.time.LocalDate.parse(view.getTableAttendance().getValueAt(row, 0).toString());
        payrollsystem.model.DailyTimeRecord dtr = getDtrByDate(selectedDate);

        if (dtr == null || dtr.getTimeOut() == null || !dtr.getTimeOut().isAfter(currentViewedEmployee.getShiftEndTime())) {
            javax.swing.JOptionPane.showMessageDialog(view, "Validation Error: No Overtime hours recorded for this date.", "Action Blocked", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        String choice = view.getCmbOtApproval().getSelectedItem().toString();
        if (choice.equals("Approve")) dtr.setOtApproved(true);
        else if (choice.equals("Deny") || choice.equals("Clear Status")) dtr.setOtApproved(false);

        saveAndRefresh("Overtime status updated.");
    }

    private void applyDayType() {
        int row = view.getTableAttendance().getSelectedRow();
        if (row < 0) return;

        java.time.LocalDate selectedDate = java.time.LocalDate.parse(view.getTableAttendance().getValueAt(row, 0).toString());
        payrollsystem.model.DailyTimeRecord dtr = getDtrByDate(selectedDate);

        // If Admin is setting a holiday on a day the employee hasn't worked yet, create a blank DTR for it
        if (dtr == null) {
            dtr = new payrollsystem.model.DailyTimeRecord(selectedDate, null, null, "NO RECORD");
            currentViewedEmployee.getDtrRecords().add(dtr);
        }

        String type = view.getCmbDayType().getSelectedItem().toString();
        
        dtr.setRegularHoliday(false);
        dtr.setSpecialHoliday(false);
        dtr.setRestDay(false);

        if (type.equals("Regular Holiday")) dtr.setRegularHoliday(true);
        else if (type.equals("Special Non-Working")) dtr.setSpecialHoliday(true);
        else if (type.equals("Rest Day")) dtr.setRestDay(true);

        saveAndRefresh("Day type updated.");
    }

    private void saveAndRefresh(String message) {
        payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
        int selectedRow = view.getTableAttendance().getSelectedRow(); 
        refreshAttendanceTable();
        // Reselect row safely
        if (selectedRow >= 0 && selectedRow < view.getTableAttendance().getRowCount()) {
            view.getTableAttendance().setRowSelectionInterval(selectedRow, selectedRow);
        }
        javax.swing.JOptionPane.showMessageDialog(view, message, "Success", javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }

    private void saveTableStateToDatabase() {
        if (currentViewedEmployee == null) return;
        
        // In a real system we would parse the table and update the currentViewedEmployee's DTR List here.
        // For brevity, we simply trigger the FileStorageManager save.
        FileStorageManager.saveEmployees(employeeDatabase);
    }

    // --- LAY 3: PAYSLIP GENERATION & RELEASE ---

    private void generatePayslip(payrollsystem.model.Employee targetEmp) {
        // 1. Get Attendance Summary (This now automatically includes 8 hours for any approved leave)
        payrollsystem.model.AttendanceSummary summary = 
            payrollsystem.utils.AttendanceCalculator.calculateMetrics(targetEmp, targetEmp.getDtrRecords());
        
        // 2. Rate Math 
        double monthlyRate = targetEmp.getSalaryRate();
        double hourlyRate = monthlyRate / 160.0; 
        
        // 3. Timekeeping based strictly on total hours generated
        double basePay = summary.getBasicWorkedHours() * hourlyRate;
        double otPay = summary.getRegularOtHours() * (hourlyRate * 1.25);
        double lateUndertimeDeduction = summary.getLateUndertimeHours() * hourlyRate;
        
        // 4. Track Holiday Premiums
        double holidayPremium = 0.0;
        for (payrollsystem.model.DailyTimeRecord dtr : targetEmp.getDtrRecords()) {
            if (dtr.getTimeIn() != null && dtr.getTimeOut() != null) {
                long minutesWorked = java.time.temporal.ChronoUnit.MINUTES.between(dtr.getTimeIn(), dtr.getTimeOut());
                if (minutesWorked < 0) minutesWorked += 24 * 60; 
                double hoursWorked = Math.min(minutesWorked / 60.0, 8.0); 
                
                if (dtr.isRegularHoliday()) {
                    holidayPremium += hoursWorked * (hourlyRate * 1.0); 
                } else if (dtr.isSpecialHoliday()) {
                    holidayPremium += hoursWorked * (hourlyRate * 0.30); 
                }
            }
        }
        
        // 5. TRUE GROSS EARNINGS 
        double trueGrossEarnings = basePay + otPay + holidayPremium - lateUndertimeDeduction;
        if (trueGrossEarnings < 0) trueGrossEarnings = 0;

        // 6. Statutory Deductions based on Total Hours compensation
        double sss = payrollsystem.utils.PayrollCalculator.getSSSEmployeeShare(trueGrossEarnings);
        double philHealth = payrollsystem.utils.PayrollCalculator.getPhilHealthShare(trueGrossEarnings);
        double pagIbig = payrollsystem.utils.PayrollCalculator.getPagIBIGShare();
        
        if (trueGrossEarnings == 0) {
            sss = 0; philHealth = 0; pagIbig = 0;
        }
        
        double taxableIncome = trueGrossEarnings - (sss + philHealth + pagIbig);
        if (taxableIncome < 0) taxableIncome = 0;
        double tax = payrollsystem.utils.PayrollCalculator.calculateTax(taxableIncome);
        
        double totalStatutoryAndTax = sss + philHealth + pagIbig + tax;
        double earningsAfterStatutory = trueGrossEarnings - totalStatutoryAndTax;
        if (earningsAfterStatutory < 0) earningsAfterStatutory = 0;
        
        double loanDeduction = targetEmp.getLoanBalance();
        if (loanDeduction > earningsAfterStatutory) {
            loanDeduction = earningsAfterStatutory;
        }
        
        double netPay = earningsAfterStatutory - loanDeduction;
        if (netPay < 0) netPay = 0; 
        
        // 7. Payslip String formatting
        String payslipBreakdown = String.format(
            "==========================================\n" +
            "             PAYSLIP SUMMARY              \n" +
            "==========================================\n" +
            "Employee:    %s\n" +
            "ID:          %s\n" +
            "Cutoff:      %s\n" +
            "------------------------------------------\n" +
            "EARNINGS:\n" +
            "  Basic Pay (Total Hours: %5.2f): PHP %,10.2f\n" +
            "  Less: Late/Undertime:        ( PHP %,10.2f )\n" +
            "  Overtime Pay:                  PHP %,10.2f\n" +
            "  Holiday Premium:               PHP %,10.2f\n" +
            "------------------------------------------\n" +
            "GROSS EARNINGS:                  PHP %,10.2f\n" +
            "------------------------------------------\n" +
            "STATUTORY & TAX:\n" +
            "  SSS Contribution:              PHP %,10.2f\n" +
            "  PhilHealth Contribution:       PHP %,10.2f\n" +
            "  Pag-IBIG Contribution:         PHP %,10.2f\n" +
            "  Withholding Tax:               PHP %,10.2f\n" +
            "------------------------------------------\n" +
            "EARNINGS AFTER:                  PHP %,10.2f\n" +
            "------------------------------------------\n" +
            "PERSONAL DEDUCTIONS:\n" +
            "  Loan Payment:                  PHP %,10.2f\n" +
            "==========================================\n" +
            "NET PAY:                         PHP %,10.2f\n" +
            "==========================================\n",
            targetEmp.getName(), targetEmp.getId(), targetEmp.getCutoffPeriod(),
            summary.getBasicWorkedHours(), basePay, lateUndertimeDeduction, otPay, holidayPremium, 
            trueGrossEarnings,
            sss, philHealth, pagIbig, tax, 
            earningsAfterStatutory, 
            loanDeduction, 
            netPay
        );
        
        // 8. Finalize and Save
        targetEmp.addPayslip(new payrollsystem.model.PayslipRecord(java.time.LocalDate.now(), trueGrossEarnings, netPay, payslipBreakdown));
        
        double newLoanBalance = targetEmp.getLoanBalance() - loanDeduction;
        targetEmp.setLoanBalance(newLoanBalance < 0 ? 0 : newLoanBalance);
        
        payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
        
        view.getTxtPayslip().setText(payslipBreakdown);
        javax.swing.JOptionPane.showMessageDialog(view, "Payslip generated successfully.");
    }

    private void releasePayslip() {
        if (currentViewedEmployee == null) return;
        
        String text = view.getTxtPayslip().getText();
        if (text.isEmpty() || text.contains("HERE IS YOUR PAYSLIP")) {
            JOptionPane.showMessageDialog(view, "Please generate a payslip first.");
            return;
        }

        PayslipRecord pr = new PayslipRecord(LocalDate.now(), 0.0, 0.0, text); // Gross/Net params can be fed from your math
        currentViewedEmployee.addPayslip(pr);
        FileStorageManager.saveEmployees(employeeDatabase);
        
        JOptionPane.showMessageDialog(view, "Payslip officially released to " + currentViewedEmployee.getName());
    }
    
    // --- LOGOUT LOGIC ---
    private void logout() {
        // Optional: You can add a confirmation dialog here if you want
        int confirm = javax.swing.JOptionPane.showConfirmDialog(view, "Are you sure you want to log out?", "Confirm Logout", javax.swing.JOptionPane.YES_NO_OPTION);
        
        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            view.dispose(); // Close the Admin Dashboard
            
            // Launch a fresh Login Screen
            payrollsystem.view.LoginView loginView = new payrollsystem.view.LoginView();
            new payrollsystem.controller.LoginController(loginView);
            loginView.setLocationRelativeTo(null);
            loginView.setVisible(true);
        }
    }
    
    // --- HELPER METHOD: Fetch specific DTRs for Holiday calculations ---
    private payrollsystem.model.DailyTimeRecord getRecordByDate(payrollsystem.model.Employee emp, java.time.LocalDate date) {
        for (payrollsystem.model.DailyTimeRecord dtr : emp.getDtrRecords()) {
            if (dtr.getDate().equals(date)) {
                return dtr;
            }
        }
        return null;
    }   
        // --- LEAVE APPROVAL & DEDUCTION LOGIC ---
    private void processLeaveApproval(payrollsystem.model.Employee targetEmp, payrollsystem.model.DailyTimeRecord selectedDtr) {
        String currentStatus = selectedDtr.getStatus();
        
        // Safety check to ensure the status isn't empty
        if (currentStatus == null) return; 
        
        String leaveType = currentStatus.toUpperCase();

        // 1. Process Sick Leave Deductions
        if (leaveType.contains("SICK")) {
            int currentSick = targetEmp.getSickLeaveBalance();
            if (currentSick > 0) {
                targetEmp.setSickLeaveBalance(currentSick - 1);
                selectedDtr.setStatus("SICK LEAVE APPROVED");
                
                // ADD THIS TRACER:
                System.out.println("DEBUG: Deducted Sick Leave for " + targetEmp.getName() + ". New Balance: " + targetEmp.getSickLeaveBalance());
            } else {
                javax.swing.JOptionPane.showMessageDialog(view, "Warning: Employee has 0 Sick Leave balance. Marking as UNPAID SICK LEAVE.");
                selectedDtr.setStatus("UNPAID SICK LEAVE");
            }
            
        // 2. Process Vacation Leave Deductions
        } else if (leaveType.contains("VACATION")) {
            int currentVacation = targetEmp.getVacationLeaveBalance();
            if (currentVacation > 0) {
                targetEmp.setVacationLeaveBalance(currentVacation - 1);
                selectedDtr.setStatus("VACATION LEAVE APPROVED");
            } else {
                javax.swing.JOptionPane.showMessageDialog(view, "Warning: Employee has 0 Vacation Leave balance. Marking as UNPAID VACATION LEAVE.");
                selectedDtr.setStatus("UNPAID VACATION LEAVE");
            }
            
        // 3. Normal Attendance Approval
        } else {
            selectedDtr.setStatus("APPROVED");
        }

        // 4. Save to Database instantly
        payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
        
        javax.swing.JOptionPane.showMessageDialog(view, "Status updated and database saved.");
    }
}
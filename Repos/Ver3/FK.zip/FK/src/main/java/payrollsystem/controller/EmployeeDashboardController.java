package payrollsystem.controller;

import payrollsystem.model.Employee;
import payrollsystem.model.DailyTimeRecord;
import payrollsystem.model.AttendanceSummary;
import payrollsystem.utils.AttendanceCalculator;
import payrollsystem.view.EmployeeDashboardView;
import payrollsystem.view.LoginView;

import javax.swing.Timer;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class EmployeeDashboardController {
    private EmployeeDashboardView view;
    private Employee loggedInEmployee;
    private List<Employee> employeeDatabase;
    private Timer clockTimer;

    public EmployeeDashboardController(EmployeeDashboardView view, Employee employee, List<Employee> database) {
        this.view = view;
        this.loggedInEmployee = employee;
        this.employeeDatabase = database;
        
        initController();
        startLiveClock();
        loadProfileData();
        
        // Start on Profile Panel by default
        switchPanel(view.getLay1());
    }

    private void initController() {
        // --- NAVIGATION ---
        view.getBtnMyProfile().addActionListener(e -> switchPanel(view.getLay1()));
        view.getBtnTimePuncher().addActionListener(e -> {
            switchPanel(view.getLay2());
            refreshTimekeepingPanel(); // Recalculate stats whenever they open this tab
        });
        view.getBtnMyPayslips().addActionListener(e -> switchPanel(view.getLay3()));
        view.getBtnLeaveRequests().addActionListener(e -> switchPanel(view.getLay4()));
        view.getBtnLogout().addActionListener(e -> logout());

        // --- ACTION BUTTONS ---
        view.getBtnPunchTime().addActionListener(e -> punchTime());
        // (Leave and Payslip listeners will be added here in the next steps)
        // --- PASSWORD UPDATE CONTROLS ---
        setupPlaceholder(view.getTxtUpdatePassword(), "Type new password here...");
        
        view.getBtnUpdatePassword().addActionListener(e -> updatePassword());
        view.getTxtUpdatePassword().addActionListener(e -> updatePassword()); // Allows hitting "Enter" to save
        
        setupPlaceholder(view.getTxtLeaveDate(), "YYYY-MM-DD");
        view.getBtnSubmitLeave().addActionListener(e -> submitLeaveRequest());
    }

    // --- HELPER METHODS ---

    private void switchPanel(javax.swing.JPanel panel) {
        view.getLay1().setVisible(false);
        view.getLay2().setVisible(false);
        view.getLay3().setVisible(false);
        view.getLay4().setVisible(false);
        panel.setVisible(true);
    }

    private void startLiveClock() {
        clockTimer = new Timer(1000, e -> {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy  |  hh:mm:ss a");
            view.getLblLiveClock().setText(java.time.LocalDateTime.now().format(formatter));
        });
        clockTimer.start();
    }

    private void loadProfileData() {
        // Lock fields so the employee cannot edit their own profile
        view.getTxtId().setEditable(false);
        view.getTxtName().setEditable(false);
        view.getTxtType().setEditable(false);
        view.getTxtSalary().setEditable(false);
        view.getTxtCutoff().setEditable(false);
        view.getTxtMonthOf().setEditable(false); // NEW: Lock the month field
        
        
        // Fetch and format the current month and year (e.g., "MAY 2026")
        java.time.LocalDate now = java.time.LocalDate.now();
        String currentMonth = now.getMonth().name() + " " + now.getYear();
        
        // Load data into fields
        view.getTxtId().setText(loggedInEmployee.getId());
        view.getTxtName().setText(loggedInEmployee.getName());
        view.getTxtType().setText(loggedInEmployee.getEmployeeType());
        view.getTxtSalary().setText(String.valueOf(loggedInEmployee.getSalaryRate()));
        view.getTxtCutoff().setText(loggedInEmployee.getCutoffPeriod());
        view.getTxtPassword().setText(loggedInEmployee.getPassword());
        
        // Set the dynamic month
        view.getTxtMonthOf().setText(currentMonth);
        view.getTxtLoans().setText(String.format("₱%.2f", loggedInEmployee.getLoanBalance()));
    }

    private void refreshTimekeepingPanel() {
        LocalDate today = LocalDate.now();
        DailyTimeRecord todayRecord = getRecordByDate(today);
        DailyTimeRecord openRecord = getOpenTimeRecord(); // Check for midnight crossovers

        // 1. Update the Dynamic Punch Button
        if (openRecord != null) {
            // There is an active shift (from today OR yesterday) waiting to be closed
            view.getBtnPunchTime().setText("Punch Out");
            view.getBtnPunchTime().setEnabled(true);
        } else if (todayRecord == null || todayRecord.getTimeIn() == null) {
            // No active shift, and today hasn't been started
            view.getBtnPunchTime().setText("Punch In");
            view.getBtnPunchTime().setEnabled(true);
        } else {
            // Shift completed for today
            view.getBtnPunchTime().setText("Shift Completed");
            view.getBtnPunchTime().setEnabled(false);
        }

        // 2. Populate the Table (UPGRADED PRE-FILL LOGIC)
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) view.getTableMyAttendance().getModel();
        model.setRowCount(0);

        int year = java.time.LocalDate.now().getYear(); 
        int month = java.time.LocalDate.now().getMonthValue(); 
        
        String cutoff = loggedInEmployee.getCutoffPeriod();
        int startDay = (cutoff != null && cutoff.startsWith("16th")) ? 16 : 1;
        int endDay = (startDay == 1) ? 15 : java.time.YearMonth.of(year, month).lengthOfMonth();

        for (int i = startDay; i <= endDay; i++) {
            java.time.LocalDate date = java.time.LocalDate.of(year, month, i);
            DailyTimeRecord matchingDtr = getRecordByDate(date);
            String dayStr = date.toString();
            
            if (matchingDtr != null) {
                // Show existing records
                String tIn = matchingDtr.getTimeIn() != null ? matchingDtr.getTimeIn().toString() : "--";
                String tOut = matchingDtr.getTimeOut() != null ? matchingDtr.getTimeOut().toString() : "--";
                
                String leaveStr = matchingDtr.getStatus().contains("LEAVE") ? matchingDtr.getStatus() : "No Leave";
                String otStr = matchingDtr.isOtApproved() ? "OT Approved" : "No OT";
                String combinedStatus = "(" + leaveStr + ", " + otStr + ")";
                
                String dayType = "Regular";
                if (matchingDtr.isRegularHoliday()) dayType = "Regular Holiday";
                else if (matchingDtr.isSpecialHoliday()) dayType = "Special Non-Working";
                else if (matchingDtr.isRestDay()) dayType = "Rest Day";

                model.addRow(new Object[]{dayStr, tIn, tOut, combinedStatus, dayType});
            } else {
                // Show blank rows with auto-detected weekends
                java.time.DayOfWeek dow = date.getDayOfWeek();
                String defaultDayType = (dow == java.time.DayOfWeek.SATURDAY || dow == java.time.DayOfWeek.SUNDAY) ? "Rest Day" : "Regular";
                model.addRow(new Object[]{dayStr, "--", "--", "NO RECORD", defaultDayType});
            }
        }

        // 3. Update the Live Stat Trackers using the Calculator Engine
        AttendanceSummary summary = AttendanceCalculator.calculateMetrics(loggedInEmployee, loggedInEmployee.getDtrRecords());
        
        view.getLblTotalHours().setText("Total Hours: " + String.format("%.2f", summary.getBasicWorkedHours()));
        view.getLblLateUndertime().setText("Late/Undertime: " + String.format("%.2f", summary.getLateUndertimeHours()));
        view.getLblAbsent().setText("Absences: " + summary.getTotalAbsences());
        view.getLblSickLeave().setText("Sick Leave Balance: " + loggedInEmployee.getSickLeaveBalance());
        view.getLblVacationLeave().setText("Vacation Balance: " + loggedInEmployee.getVacationLeaveBalance());
        view.getLblApprovedOt().setText("Approved OT: " + String.format("%.2f", summary.getRegularOtHours()));
    }

    private void punchTime() {
        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now().truncatedTo(java.time.temporal.ChronoUnit.SECONDS);
        
        // --- 1. STRICT CUTOFF VALIDATOR ---
        int currentDay = today.getDayOfMonth();
        String cutoff = loggedInEmployee.getCutoffPeriod();
        boolean isValidCutoff = false;
        
        if (cutoff != null && cutoff.startsWith("16th")) {
            if (currentDay >= 16) isValidCutoff = true;
        } else {
            if (currentDay >= 1 && currentDay <= 15) isValidCutoff = true;
        }

        if (!isValidCutoff) {
            javax.swing.JOptionPane.showMessageDialog(view, 
                "Action Denied: Today's date (" + today + ") is outside your active cutoff period (" + cutoff + ").", 
                "Cutoff Validation Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return; 
        }
        // ----------------------------------

        DailyTimeRecord openRecord = getOpenTimeRecord();

        if (openRecord != null) {
            
            // --- GHOST SHIFT DETECTOR ---
            long daysPassed = java.time.temporal.ChronoUnit.DAYS.between(openRecord.getDate(), today);
            
            // If it is the next day AND it's already past their normal shift start time (or it's been 2+ days)
            if (daysPassed >= 1 && (now.isAfter(loggedInEmployee.getShiftStartTime()) || daysPassed > 1)) {
                
                // 1. Flag the old shift for Admin review
                openRecord.setStatus("INVALID: MISSED PUNCH OUT");
                javax.swing.JOptionPane.showMessageDialog(view, 
                    "System Alert: You failed to punch out of a previous shift.\nThat shift has been flagged for Admin review.", 
                    "Missed Punch Detected", javax.swing.JOptionPane.WARNING_MESSAGE);
                
                // 2. Ensure they haven't already punched in for TODAY
                DailyTimeRecord todayRecord = getRecordByDate(today);
                if (todayRecord == null) {
                    // Create a brand new shift for today since their new shift has started
                    todayRecord = new DailyTimeRecord(today, now, null, "PRESENT");
                    loggedInEmployee.getDtrRecords().add(todayRecord);
                    javax.swing.JOptionPane.showMessageDialog(view, "Successfully Punched In for TODAY at " + now);
                }
                
            } else {
                // LOGIC: NORMAL PUNCH OUT (Same day, or early next morning before next shift starts)
                openRecord.setTimeOut(now);
                javax.swing.JOptionPane.showMessageDialog(view, "Successfully Punched Out at " + now);
            }
            
        } else {
            // LOGIC: NORMAL PUNCH IN
            DailyTimeRecord todayRecord = getRecordByDate(today);
            
            // Prevent punching in twice in one day
            if (todayRecord != null && todayRecord.getTimeOut() != null) {
                javax.swing.JOptionPane.showMessageDialog(view, "You have already completed your shift for today.", "Action Denied", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            todayRecord = new DailyTimeRecord(today, now, null, "PRESENT");
            loggedInEmployee.getDtrRecords().add(todayRecord);
            javax.swing.JOptionPane.showMessageDialog(view, "Successfully Punched In at " + now);
        }

        // Save to file and instantly refresh the UI
        payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
        refreshTimekeepingPanel();
    }

    private void logout() {
        if (clockTimer != null) clockTimer.stop(); // Stop the thread to prevent memory leaks
        view.dispose();
        
        LoginView loginView = new LoginView();
        new LoginController(loginView);
        loginView.setLocationRelativeTo(null);
        loginView.setVisible(true);
    }
    
    // --- LEAVE REQUEST LOGIC ---
    private void submitLeaveRequest() {
        String dateStr = view.getTxtLeaveDate().getText().trim();
        String leaveType = view.getCmbLeaveType().getSelectedItem().toString(); 

        // 1. Validate Date Format (Basic check for YYYY-MM-DD)
        java.time.LocalDate requestDate;
        try {
            requestDate = java.time.LocalDate.parse(dateStr);
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(view, 
                "Invalid Date Format. Please use YYYY-MM-DD (e.g., 2026-05-25)", 
                "Input Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 2. Validate Leave Balance
        if (leaveType.equals("Sick Leave") && loggedInEmployee.getSickLeaveBalance() <= 0) {
            javax.swing.JOptionPane.showMessageDialog(view, "You have zero Sick Leave balance remaining.", "Request Denied", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        } else if (leaveType.equals("Vacation Leave") && loggedInEmployee.getVacationLeaveBalance() <= 0) {
            javax.swing.JOptionPane.showMessageDialog(view, "You have zero Vacation Leave balance remaining.", "Request Denied", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 3. Check if a record already exists for this date
        payrollsystem.model.DailyTimeRecord existingRecord = getRecordByDate(requestDate);
        if (existingRecord != null) {
            if (existingRecord.getStatus().contains("LEAVE")) {
                javax.swing.JOptionPane.showMessageDialog(view, "You already have a leave request for this date.", "Duplicate Request", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            } else if (existingRecord.getTimeIn() != null) {
                javax.swing.JOptionPane.showMessageDialog(view, "You cannot request leave for a day you already punched in for.", "Invalid Request", javax.swing.JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // 4. Create and save the Leave Request
        if (existingRecord == null) {
            payrollsystem.model.DailyTimeRecord leaveDtr = new payrollsystem.model.DailyTimeRecord(requestDate, null, null, "LEAVE PENDING");
            leaveDtr.setLeaveType(leaveType);
            loggedInEmployee.getDtrRecords().add(leaveDtr);
        } else {
            existingRecord.setStatus("LEAVE PENDING");
            existingRecord.setLeaveType(leaveType);
        }

        // Save to file
        payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
        
        javax.swing.JOptionPane.showMessageDialog(view, "Leave Request submitted successfully! Awaiting Admin approval.", "Success", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
        // Reset the form
        view.getTxtLeaveDate().setText(""); 
        setupPlaceholder(view.getTxtLeaveDate(), "YYYY-MM-DD");
        view.getBtnSubmitLeave().requestFocusInWindow();
        
        refreshTimekeepingPanel(); // Refresh stats so it shows on the table
    }
    
    private DailyTimeRecord getRecordByDate(LocalDate date) {
        for (DailyTimeRecord dtr : loggedInEmployee.getDtrRecords()) {
            if (dtr.getDate().equals(date)) return dtr;
        }
        return null;
    }
    
    // --- MIDNIGHT CROSSING HELPER ---
    private DailyTimeRecord getOpenTimeRecord() {
        // 1. Check if TODAY has an open shift (Punched In, but not Out)
        DailyTimeRecord todayRec = getRecordByDate(LocalDate.now());
        if (todayRec != null && todayRec.getTimeIn() != null && todayRec.getTimeOut() == null) {
            return todayRec;
        }
        
        // 2. Check if YESTERDAY has an open shift (They worked past midnight!)
        DailyTimeRecord yesterdayRec = getRecordByDate(LocalDate.now().minusDays(1));
        if (yesterdayRec != null && yesterdayRec.getTimeIn() != null && yesterdayRec.getTimeOut() == null) {
            return yesterdayRec;
        }
        
        return null; // No open shifts found
    }
    
    // --- PASSWORD UPDATE LOGIC ---
    private void updatePassword() {
        // Grab the text from your dedicated new password field
        String newPassword = view.getTxtUpdatePassword().getText().trim();

        // 1. Validate Input
        if (newPassword.isEmpty() || newPassword.equals("Type new password here...")) {
            javax.swing.JOptionPane.showMessageDialog(view, 
                "Please enter a valid new password before updating.", 
                "Validation Error", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. The "Are You Sure?" Confirmation
        int confirm = javax.swing.JOptionPane.showConfirmDialog(view, 
            "Are you sure you want to change your password to this new value?", 
            "Confirm Password Change", 
            javax.swing.JOptionPane.YES_NO_OPTION,
            javax.swing.JOptionPane.QUESTION_MESSAGE);

        // 3. Execution
        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            loggedInEmployee.setPassword(newPassword);
            
            payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
            
            // ---> THE FIX: Update the display field with the new password <---
            view.getTxtPassword().setText(newPassword); 
            
            javax.swing.JOptionPane.showMessageDialog(view, 
                "Password updated successfully!", 
                "Security Update", 
                javax.swing.JOptionPane.INFORMATION_MESSAGE);
            
            // Reset the dedicated input field back to the placeholder state
            view.getTxtUpdatePassword().setText("");
            setupPlaceholder(view.getTxtUpdatePassword(), "Type new password here...");
            
            // Move the cursor focus away so the placeholder visually reappears
            view.getBtnUpdatePassword().requestFocusInWindow();
        }
    }
    
    // --- UI HELPER: PLACEHOLDER LOGIC ---
    private void setupPlaceholder(javax.swing.JTextField textField, String placeholderText) {
        // 1. Set the initial placeholder state if the field is empty
        if (textField.getText().isEmpty()) {
            textField.setForeground(java.awt.Color.GRAY);
            textField.setText(placeholderText);
        }

        // 2. Add the listener to detect when the user clicks in and out
        textField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                // When they click IN, clear the placeholder text
                if (textField.getText().equals(placeholderText)) {
                    textField.setText("");
                    textField.setForeground(java.awt.Color.BLACK); // Set to normal typing color
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                // When they click OUT, restore the placeholder if they typed nothing
                if (textField.getText().isEmpty()) {
                    textField.setForeground(java.awt.Color.GRAY);
                    textField.setText(placeholderText);
                }
            }
        });
    }
    
}
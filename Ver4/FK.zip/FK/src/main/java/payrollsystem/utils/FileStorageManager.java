package payrollsystem.utils;

import payrollsystem.model.Employee; // Adjust this import based on your exact folder structure
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileStorageManager {
    
    // The flat file where all data will be serialized
    private static final String FILE_NAME = "employees.dat";

    /**
     * Serializes and saves the list of employees to the flat file.
     * @param employees
     */
    public static void saveEmployees(List<Employee> employees) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(employees);
            System.out.println("Data successfully saved to " + FILE_NAME);
        } catch (IOException e) {
            System.err.println("Critical Error saving employee data: " + e.getMessage());
        }
    }

    /**
     * Deserializes and loads the list of employees from the flat file.
     * Returns an empty list if the file does not exist yet.
     * @return 
     */
    @SuppressWarnings("unchecked")
    public static List<Employee> loadEmployees() {
        File file = new File(FILE_NAME);
        
        // If the database doesn't exist yet (first run), return an empty list
        if (!file.exists()) {
            System.out.println("No existing database found. Initializing empty system.");
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Employee>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Critical Error loading employee data: " + e.getMessage());
            // Return an empty list to prevent the application from crashing on boot
            return new ArrayList<>(); 
        }
    }
}

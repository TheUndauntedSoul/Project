package com.mycompany.fk.models;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class EmployeeData implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String fullName;
    private String type; // Regular, Probationary, etc.
    private double monthlySalary;
    private List<AttendanceRecord> attendanceLog;

    public EmployeeData(String id, String fullName, String type, double monthlySalary) {
        this.id = id;
        this.fullName = fullName;
        this.type = type;
        this.monthlySalary = monthlySalary;
        this.attendanceLog = new ArrayList<>();
    }

    // Getters and Setters
    public String getId() { return id; }
    public String getFullName() { return fullName; }
    public String getType() { return type; }
    public double getMonthlySalary() { return monthlySalary; }
    public List<AttendanceRecord> getAttendanceLog() { return attendanceLog; }
    
    public void addAttendance(AttendanceRecord record) {
        this.attendanceLog.add(record);
    }
}

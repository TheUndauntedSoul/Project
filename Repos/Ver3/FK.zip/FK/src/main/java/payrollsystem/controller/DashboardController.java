package payrollsystem.controller;

import payrollsystem.model.*;
import payrollsystem.utils.FileStorageManager;
import payrollsystem.utils.PayrollCalculator;
import payrollsystem.view.DashboardView;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.DateTimeException;
import java.util.List;

public class DashboardController {
    
    private DashboardView view;
    private Employee loggedInUser;
    private boolean isAdmin;
    
    // Database State
    private List<Employee> employeeDatabase;
    private Employee currentViewedEmployee; // The employee the Admin is currently looking at

    private boolean isUpdatingTable = false;

    public DashboardController(DashboardView view, Employee loggedInUser, boolean isAdmin) {
        this.view = view;
        this.loggedInUser = loggedInUser;
        this.isAdmin = isAdmin;
        this.employeeDatabase = FileStorageManager.loadEmployees();
        
        initView();
        initController();
    }

    private void initView() {
        switchPanel(true, false, false);

        if (!isAdmin) {
            // Lock UI for regular employees
            view.getTxtName().setText(loggedInUser.getName());
            view.getTxtName().setEditable(false);
            view.getTxtId().setText(loggedInUser.getId());
            view.getTxtId().setEditable(false);
            view.getTxtSalary().setText(String.valueOf(loggedInUser.getSalaryRate()));
            view.getTxtSalary().setEditable(false);
            view.getCmbType().setSelectedItem(loggedInUser.getEmployeeType());
            view.getCmbType().setEnabled(false);
            view.getCmbCutoff().setSelectedItem(loggedInUser.getCutoffPeriod());
            view.getCmbCutoff().setEnabled(false);
            
            // Hide Admin controls
            view.getBtnCreateEmployee().setVisible(false);
            view.getBtnUpdateEmployee().setVisible(false);
            view.getBtnDeleteEmployee().setVisible(false);
            view.getTxtPassword().setVisible(false);
            
            currentViewedEmployee = loggedInUser;
            refreshAttendanceTable();
        }
    }

    private void initController() {
        // Navigation Wiring
        view.getBtnEmployeeInfo().addActionListener(e -> switchPanel(true, false, false));
        view.getBtnTimeTable().addActionListener(e -> switchPanel(false, true, false));
        view.getBtnPayslip().addActionListener(e -> switchPanel(false, false, true));

        // Dynamic ComboBox Triggers
        view.getCmbType().addActionListener(e -> {
            String type = view.getCmbType().getSelectedItem().toString();
            if (type.equalsIgnoreCase("Part-Timer")) {
                view.getLblSalaryTitle().setText("Hourly Rate:");
            } else {
                view.getLblSalaryTitle().setText("Monthly Salary Rate:");
            }
            refreshAttendanceTable();
        });
        
        view.getCmbCutoff().addActionListener(e -> refreshAttendanceTable());
        view.getMonthChooser().addPropertyChangeListener("month", e -> refreshAttendanceTable());

        // Lay 1: Admin Controls (Create, Update, Delete)
        if (isAdmin) {
            view.getBtnCreateEmployee().addActionListener(e -> createEmployee());
            view.getBtnUpdateEmployee().addActionListener(e -> updateEmployee());
            view.getBtnDeleteEmployee().addActionListener(e -> deleteEmployee());
        }

        // Lay 2: Time Table Controls
        view.getBtnSearchLay2().addActionListener(e -> searchEmployee(view.getTxtSearchIdLay2().getText().trim(), 2));
        view.getBtnApproveLeave().addActionListener(e -> updateLeaveStatus("LEAVE APPROVED"));
        view.getBtnDenyLeave().addActionListener(e -> updateLeaveStatus("LEAVE DENIED"));
        
        view.getTableAttendance().getModel().addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) { handleTableChange(e); }
        });

        // Lay 3: Payslip Controls
        view.getBtnSearchLay3().addActionListener(e -> searchEmployee(view.getTxtSearchIdLay3().getText().trim(), 3));
        view.getBtnGeneratePayslip().addActionListener(e -> generatePayslip());
        view.getBtnReleasePayslip().addActionListener(e -> releasePayslip());

        // Initialize strict field validators
        initValidationListeners();
    }

    private void initValidationListeners() {
        // ID Validation (Format check + Auto-shift focus on Enter)
        view.getTxtId().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validateIdField(); }
        });
        view.getTxtId().addActionListener(e -> { 
            if (validateIdField()) view.getTxtPassword().requestFocusInWindow(); 
        });

        // Password Validation (Cannot be empty placeholder)
        view.getTxtPassword().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validatePasswordField(); }
        });
        view.getTxtPassword().addActionListener(e -> { 
            if (validatePasswordField()) view.getTxtSalary().requestFocusInWindow(); 
        });

        // Salary Validation (Must be a positive number)
        view.getTxtSalary().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validateSalaryField(); }
        });
        view.getTxtSalary().addActionListener(e -> { 
            if (validateSalaryField()) view.getTxtLoans().requestFocusInWindow(); 
        });
        
        // Lay 2 Search ID Validation
        view.getTxtSearchIdLay2().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validateSearchIdField(view.getTxtSearchIdLay2()); }
        });
        view.getTxtSearchIdLay2().addActionListener(e -> { 
            if (validateSearchIdField(view.getTxtSearchIdLay2())) view.getBtnSearchLay2().doClick(); 
        });

        // Lay 3 Search ID Validation
        view.getTxtSearchIdLay3().addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) { validateSearchIdField(view.getTxtSearchIdLay3()); }
        });
        view.getTxtSearchIdLay3().addActionListener(e -> { 
            if (validateSearchIdField(view.getTxtSearchIdLay3())) view.getBtnSearchLay3().doClick(); 
        });
    }

    // --- STRICT VALIDATOR HELPERS ---
    private boolean validateIdField() {
        String id = view.getTxtId().getText().trim();
        if (id.equals("(xxxx-xxxx-xx)") || id.isEmpty()) return false; // Ignore placeholders
        if (!id.matches("\\d{4}-\\d{4}-\\d{2}")) {
            JOptionPane.showMessageDialog(view.getLay1(), "Format Error: ID must be XXXX-XXXX-XX", "Validation Error", JOptionPane.ERROR_MESSAGE);
            view.getTxtId().requestFocusInWindow();
            return false;
        }
        return true;
    }

    private boolean validatePasswordField() {
        String pass = view.getTxtPassword().getText().trim();
        if (pass.equals("Enter Employee Password...") || pass.isEmpty()) return false;
        if (pass.length() < 4) {
            JOptionPane.showMessageDialog(view.getLay1(), "Password must be at least 4 characters.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            view.getTxtPassword().requestFocusInWindow();
            return false;
        }
        return true;
    }

    private boolean validateSalaryField() {
        String input = view.getTxtSalary().getText().replace(",", "").trim();
        if (input.equals("Enter Salary...") || input.isEmpty()) return false;
        try {
            double val = Double.parseDouble(input);
            if (val <= 0) throw new Exception();
            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view.getLay1(), "Invalid Input: Please enter a positive numeric value for salary/rate.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            view.getTxtSalary().requestFocusInWindow();
            return false;
        }
    }
    
    private boolean validateSearchIdField(javax.swing.JTextField searchField) {
        String id = searchField.getText().trim();
        // Allow it to be empty if they just click away without intending to search
        if (id.isEmpty() || id.equals("(xxxx-xxxx-xx)")) return true; 
        
        if (!id.matches("\\d{4}-\\d{4}-\\d{2}")) {
            JOptionPane.showMessageDialog(view.getLay1(), "Format Error: Employee ID must be XXXX-XXXX-XX", "Validation Error", JOptionPane.ERROR_MESSAGE);
            searchField.requestFocusInWindow();
            return false;
        }
        return true;
    }

    // Helper to find employee by ID across methods
    private Employee findEmployeeById(String id) {
        for (Employee emp : employeeDatabase) {
            if (emp.getId().equals(id)) return emp;
        }
        return null;
    }

    private void switchPanel(boolean lay1, boolean lay2, boolean lay3) {
        view.getLay1().setVisible(lay1);
        view.getLay2().setVisible(lay2);
        view.getLay3().setVisible(lay3);
    }

    // --- LAY 1: CRUD OPERATIONS ---

    private void createEmployee() {
        // 1. Force final validation pass
        if (!validateIdField() || !validatePasswordField() || !validateSalaryField()) {
            JOptionPane.showMessageDialog(view, "Please ensure all fields contain valid data before creating.");
            return;
        }

        String id = view.getTxtId().getText().trim();
        
        // 2. Strict Duplicate Check
        if (findEmployeeById(id) != null) {
            JOptionPane.showMessageDialog(view, "Creation Failed: Employee ID '" + id + "' already exists! Use the Update button instead.", "Duplicate ID", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String name = view.getTxtName().getText().trim();
            if (name.equals("Enter Your Full Name...") || name.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Please enter a valid Name."); return;
            }

            String pass = view.getTxtPassword().getText().trim();
            String type = view.getCmbType().getSelectedItem().toString();
            String cutoff = view.getCmbCutoff().getSelectedItem().toString();
            double salary = Double.parseDouble(view.getTxtSalary().getText().replace(",", "").trim());

            Employee newEmp;
            if (type.equalsIgnoreCase("Regular")) newEmp = new RegularEmployee(name, id, pass, salary, cutoff);
            else if (type.equalsIgnoreCase("Probationary")) newEmp = new ProbationaryEmployee(name, id, pass, salary, cutoff);
            else if (type.equalsIgnoreCase("Part-Timer")) newEmp = new PartTimer(name, id, pass, salary, cutoff);
            else newEmp = new ContractualEmployee(name, id, pass, salary, cutoff);

            employeeDatabase.add(newEmp);
            FileStorageManager.saveEmployees(employeeDatabase);
            JOptionPane.showMessageDialog(view, "Employee " + name + " Created Successfully!");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "A system error occurred during creation.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateEmployee() {
        String id = view.getTxtId().getText().trim();
        
        // 1. Strict Existence Check
        Employee targetEmp = findEmployeeById(id);
        if (targetEmp == null) {
            JOptionPane.showMessageDialog(view, "Update Failed: Cannot find an employee with ID '" + id + "'.", "Not Found", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. Force validation pass
        if (!validatePasswordField() || !validateSalaryField()) {
            JOptionPane.showMessageDialog(view, "Please ensure updated fields contain valid data.");
            return;
        }

        try {
            targetEmp.setName(view.getTxtName().getText().trim());
            targetEmp.setPassword(view.getTxtPassword().getText().trim());
            targetEmp.setEmployeeType(view.getCmbType().getSelectedItem().toString());
            targetEmp.setCutoffPeriod(view.getCmbCutoff().getSelectedItem().toString());
            targetEmp.setSalaryRate(Double.parseDouble(view.getTxtSalary().getText().replace(",", "").trim()));
            
            FileStorageManager.saveEmployees(employeeDatabase);
            JOptionPane.showMessageDialog(view, "Employee " + targetEmp.getName() + " Updated Successfully!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Invalid Input data detected during update.");
        }
    }

    private void deleteEmployee() {
        String id = view.getTxtId().getText().trim();
        
        // 1. Strict Existence Check
        Employee targetEmp = findEmployeeById(id);
        if (targetEmp == null) {
            JOptionPane.showMessageDialog(view, "Delete Failed: Cannot find an employee with ID '" + id + "'.", "Not Found", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. Confirmation
        int confirm = JOptionPane.showConfirmDialog(view, "WARNING: Are you sure you want to permanently delete " + targetEmp.getName() + " (" + id + ")?", "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            employeeDatabase.remove(targetEmp);
            FileStorageManager.saveEmployees(employeeDatabase);
            JOptionPane.showMessageDialog(view, "Employee record permanently deleted.");
            
            // Clear fields after delete
            view.getTxtId().setText("(xxxx-xxxx-xx)");
            view.getTxtName().setText("Enter Your Full Name...");
            view.getTxtPassword().setText("Enter Employee Password...");
            view.getTxtSalary().setText("Enter Salary...");
        }
    }

    // --- SEARCH UTILITY ---

    private void searchEmployee(String searchId, int layNumber) {
        if (searchId.isEmpty() || searchId.equals("(xxxx-xxxx-xx)")) return;
        
        if (!searchId.matches("\\d{4}-\\d{4}-\\d{2}")) {
            JOptionPane.showMessageDialog(view, "Format Error: Search ID must be XXXX-XXXX-XX", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        for (Employee emp : employeeDatabase) {
            if (emp.getId().equals(searchId)) {
                currentViewedEmployee = emp;
                
                // Populate Lay 1 just in case
                view.getTxtId().setText(emp.getId());
                view.getTxtName().setText(emp.getName());
                view.getTxtSalary().setText(String.valueOf(emp.getSalaryRate()));
                view.getCmbType().setSelectedItem(emp.getEmployeeType());
                view.getCmbCutoff().setSelectedItem(emp.getCutoffPeriod());

                if (layNumber == 2) refreshAttendanceTable();
                if (layNumber == 3) JOptionPane.showMessageDialog(view, "Loaded " + emp.getName() + " for Payslip Generation.");
                return;
            }
        }
        JOptionPane.showMessageDialog(view, "Employee not found in database.");
    }

    // --- LAY 2: TABLE & LEAVE MANAGEMENT ---

    private void refreshAttendanceTable() {
        if (currentViewedEmployee == null) return;

        DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();
        model.setRowCount(0);

        int year = 2026; 
        int month = view.getMonthChooser().getMonth() + 1; 
        int startDay = (currentViewedEmployee.getCutoffPeriod().startsWith("1st")) ? 1 : 16;
        int endDay = (currentViewedEmployee.getCutoffPeriod().startsWith("1st")) ? 15 : 30;

        for (int i = startDay; i <= endDay; i++) {
            try {
                LocalDate date = LocalDate.of(year, month, i);
                DayOfWeek dow = date.getDayOfWeek();
                String dateLabel = i + " (" + dow.toString().substring(0, 3) + ")";
                
                // Check if DTR already exists for this date in the employee's record
                DailyTimeRecord existingDtr = null;
                for (DailyTimeRecord dtr : currentViewedEmployee.getDtrRecords()) {
                    if (dtr.getDate().equals(date)) {
                        existingDtr = dtr; break;
                    }
                }

                if (existingDtr != null) {
                    model.addRow(new Object[]{dateLabel, existingDtr.getTimeIn().toString(), existingDtr.getTimeOut().toString(), existingDtr.getStatus()});
                } else {
                    if (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY) {
                        model.addRow(new Object[]{dateLabel, "REST DAY", "REST DAY", "REST DAY"});
                    } else {
                        model.addRow(new Object[]{dateLabel, "", "", "ABSENT"}); // Default to Absent if empty
                    }
                }
            } catch (DateTimeException ex) { break; }
        }
    }

    private void updateLeaveStatus(String newStatus) {
        if (currentViewedEmployee == null || !isAdmin) return;
        
        int row = view.getTableAttendance().getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(view, "Please select a row in the table first.");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();
        String currentStatus = model.getValueAt(row, 3).toString();
        
        if (currentStatus.equals("LEAVE PENDING")) {
            model.setValueAt(newStatus, row, 3);
            saveTableStateToDatabase();
            JOptionPane.showMessageDialog(view, "Leave " + newStatus);
        } else {
            JOptionPane.showMessageDialog(view, "You can only approve or deny rows marked as LEAVE PENDING.");
        }
    }

    private void handleTableChange(TableModelEvent e) {
        if (isUpdatingTable || e.getType() != TableModelEvent.UPDATE) return;
        
        int row = e.getFirstRow();
        int col = e.getColumn();
        if (row < 0 || col < 0) return;

        DefaultTableModel model = (DefaultTableModel) view.getTableAttendance().getModel();
        String timeIn = model.getValueAt(row, 1) != null ? model.getValueAt(row, 1).toString() : "";
        String timeOut = model.getValueAt(row, 2) != null ? model.getValueAt(row, 2).toString() : "";

        isUpdatingTable = true;
        try {
            if (!timeIn.isEmpty() && !timeOut.isEmpty() && !timeIn.equals("REST DAY")) {
                model.setValueAt("PRESENT", row, 3);
            } else if ((timeIn.isEmpty() && !timeOut.isEmpty()) || (!timeIn.isEmpty() && timeOut.isEmpty())) {
                model.setValueAt("INCOMPLETE PUNCH", row, 3);
            } else if (timeIn.isEmpty() && timeOut.isEmpty()) {
                model.setValueAt("ABSENT", row, 3);
            }
        } finally {
            isUpdatingTable = false;
        }
        
        if (!isAdmin) saveTableStateToDatabase(); // Auto-save when employees punch in/out
    }

    private void saveTableStateToDatabase() {
        if (currentViewedEmployee == null) return;
        
        // In a real system we would parse the table and update the currentViewedEmployee's DTR List here.
        // For brevity, we simply trigger the FileStorageManager save.
        FileStorageManager.saveEmployees(employeeDatabase);
    }

    // --- LAY 3: PAYSLIP GENERATION & RELEASE ---

    private void generatePayslip() {
        if (currentViewedEmployee == null) {
            JOptionPane.showMessageDialog(view, "Please search for an employee first.");
            return;
        }
        
        // ... (Keep your existing math logic here, adjusting the 'absences' count by looking for "ABSENT" in column 3 instead of a boolean).
        view.getTxtPayslip().setText("PAYSLIP GENERATED FOR " + currentViewedEmployee.getName() + "\n(Math logic executes here based on Status column)");
    }

    private void releasePayslip() {
        if (currentViewedEmployee == null) return;
        
        String text = view.getTxtPayslip().getText();
        if (text.isEmpty() || text.contains("HERE IS YOUR PAYSLIP")) {
            JOptionPane.showMessageDialog(view, "Please generate a payslip first.");
            return;
        }

        PayslipRecord pr = new PayslipRecord(LocalDate.now(), 0.0, 0.0, text); // Gross/Net params can be fed from your math
        currentViewedEmployee.addPayslip(pr);
        FileStorageManager.saveEmployees(employeeDatabase);
        
        JOptionPane.showMessageDialog(view, "Payslip officially released to " + currentViewedEmployee.getName());
    }
}
package com.mycompany.fk.services;
import com.mycompany.fk.models.EmployeeData;
import com.mycompany.fk.models.AttendanceRecord;
import java.util.List;

public class EmployerService {
    private List<EmployeeData> database;

    public EmployerService() {
        this.database = FileIOService.loadEmployees();
    }

    public void createNewEmployee(String id, String name, String type, double salary) {
        EmployeeData newEmp = new EmployeeData(id, name, type, salary);
        database.add(newEmp);
        FileIOService.saveEmployees(database);
    }

    public void approveLeave(String employeeId, String date) {
        for (EmployeeData emp : database) {
            if (emp.getId().equals(employeeId)) {
                for (AttendanceRecord rec : emp.getAttendanceLog()) {
                    if (rec.getDay().equals(date) && rec.isLeaveRequested()) {
                        rec.setLeaveApproved(true);
                    }
                }
            }
        }
        FileIOService.saveEmployees(database);
    }
    
    public List<EmployeeData> getAllEmployees() {
        return database;
    }
}

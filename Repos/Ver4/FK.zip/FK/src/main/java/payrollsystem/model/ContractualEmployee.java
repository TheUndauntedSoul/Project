package payrollsystem.model;

public class ContractualEmployee extends Employee {
    private static final long serialVersionUID = 1L;

    public ContractualEmployee(String name, String id, String password, double salaryRate, String cutoffPeriod) {
        super(name, id, password, "Contractual", salaryRate, cutoffPeriod);
    }

    @Override
    public double calculateBasePay(double actualWorkedHours) {
        return getSalaryRate() / 2;
    }
}

package payrollsystem.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

public class DailyTimeRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private final LocalDate date;
    private LocalTime timeIn;
    private LocalTime timeOut;
    private String status; 
    
    // --- NEW: ADVANCED PAYROLL FLAGS ---
    private String leaveType; // "NONE", "SICK", "VACATION"
    private boolean isRegularHoliday;
    private boolean isSpecialHoliday;
    private boolean isRestDay;
    private boolean isOtApproved; // Admin must check this for OT to be paid

    public DailyTimeRecord(LocalDate date, LocalTime timeIn, LocalTime timeOut, String status) {
        this.date = date;
        this.timeIn = timeIn;
        this.timeOut = timeOut;
        this.status = status;
        
        // Defaults
        this.leaveType = "NONE";
        this.isRegularHoliday = false;
        this.isSpecialHoliday = false;
        this.isRestDay = false;
        this.isOtApproved = false;
    }

    // --- GETTERS & SETTERS ---
    public LocalDate getDate() { return date; }
    public LocalTime getTimeIn() { return timeIn; }
    public void setTimeIn(LocalTime timeIn) { this.timeIn = timeIn; }
    public LocalTime getTimeOut() { return timeOut; }
    public void setTimeOut(LocalTime timeOut) { this.timeOut = timeOut; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }
    public boolean isRegularHoliday() { return isRegularHoliday; }
    public void setRegularHoliday(boolean regularHoliday) { isRegularHoliday = regularHoliday; }
    public boolean isSpecialHoliday() { return isSpecialHoliday; }
    public void setSpecialHoliday(boolean specialHoliday) { isSpecialHoliday = specialHoliday; }
    public boolean isRestDay() { return isRestDay; }
    public void setRestDay(boolean restDay) { isRestDay = restDay; }
    public boolean isOtApproved() { return isOtApproved; }
    public void setOtApproved(boolean otApproved) { this.isOtApproved = otApproved; }
}

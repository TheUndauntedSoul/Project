package payrollsystem.controller;

import payrollsystem.model.Employee;
import payrollsystem.utils.FileStorageManager;
import payrollsystem.view.LoginView;
import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.JOptionPane;

public class LoginController {
    private final LoginView view;
    private final List<Employee> employeeDatabase;

    public LoginController(LoginView view) {
        this.view = view;
        // Load the database into memory upon controller initialization
        this.employeeDatabase = FileStorageManager.loadEmployees();
        initController();
    }

    private void initController() {
        // Attach the action listener to the button provided by the View
        this.view.getBtnLogin().addActionListener((ActionEvent e) -> {
            authenticateUser();
        });
    }

    private void authenticateUser() {
        
        String id = view.getTxtId().getText().trim();
        String pass = new String(view.getTxtPassword().getPassword()).trim();

        // Prevent the system from treating the placeholders as real credentials
        if (id.equalsIgnoreCase("Enter Employee ID...") || pass.equalsIgnoreCase("Enter Password...")) {
            javax.swing.JOptionPane.showMessageDialog(view, "Please enter your ID and Password to login.");
            return; // Stop the login process immediately
        }
        
        // Retrieve inputs from the View
        String userId = view.getTxtUserId().getText().trim();
        String password = new String(view.getTxtPassword().getPassword());

        // 1. Check Hardcoded Admin Credentials
        if (userId.equals("admin") && password.equals("adminpass")) {
            JOptionPane.showMessageDialog(view, "Admin Authentication Successful.", "System Access", JOptionPane.INFORMATION_MESSAGE);
            launchDashboard(null, true);
            return;
        }

        // 2. Check Employee Database
        for (Employee emp : employeeDatabase) {
            if (emp.getId().equals(userId) && emp.getPassword().equals(password)) {
                JOptionPane.showMessageDialog(view, "Authentication Successful. Welcome, " + emp.getName(), "System Access", JOptionPane.INFORMATION_MESSAGE);
                launchDashboard(emp, false);
                return;
            }
        }

        // 3. Fallback for Invalid Credentials
        JOptionPane.showMessageDialog(view, "Invalid User ID or Password.", "Authentication Failed", JOptionPane.ERROR_MESSAGE);
    }

    private void launchDashboard(Employee loggedInUser, boolean isAdmin) {
        System.out.println("Authentication verified. Transitioning to Dashboard...");
        
        try {
            // 1. Determine if the user is an Admin (either the hardcoded account or an Admin in the database)
            boolean isUserAdmin = isAdmin || (loggedInUser != null && loggedInUser.getEmployeeType().equalsIgnoreCase("Admin"));

            if (isUserAdmin) {
                // Launch the EMPLOYER (Admin) Dashboard
                payrollsystem.view.EmployerDashboardView dashboardView = new payrollsystem.view.EmployerDashboardView();
                new payrollsystem.controller.EmployerDashboardController(dashboardView, loggedInUser, true); // Assuming your constructor uses boolean
                
                dashboardView.pack();
                dashboardView.setLocationRelativeTo(null); 
                dashboardView.setVisible(true);
            } else {
                // Launch the EMPLOYEE Dashboard
                payrollsystem.view.EmployeeDashboardView empView = new payrollsystem.view.EmployeeDashboardView();
                new payrollsystem.controller.EmployeeDashboardController(empView, loggedInUser, employeeDatabase);
                
                empView.pack();
                empView.setLocationRelativeTo(null);
                empView.setVisible(true);
            }
            
            // 2. ONLY THEN close and dispose of the Login window
            view.setVisible(false);
            view.dispose();
            
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, 
                "Critical Error loading Dashboard:\n" + e.toString(), 
                "System Error", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
}
   
package payrollsystem.model;

public class ProbationaryEmployee extends Employee {
    private static final long serialVersionUID = 1L;

    public ProbationaryEmployee(String name, String id, String password, double salaryRate, String cutoffPeriod) {
        super(name, id, password, "Probationary", salaryRate, cutoffPeriod);
    }

    @Override
    public double calculateBasePay(double actualWorkedHours) {
        return getSalaryRate() / 2;
    }
}
package PayrollV2.model;

import java.io.Serializable;

// WHY implements Serializable: This acts as a marker telling Java that this class 
// is allowed to be converted into a file format for our local .dat storage.
public class Employee implements Serializable {
    
    // WHY serialVersionUID: This ensures that if we update this class later (e.g., add a new variable), 
    // Java won't crash when trying to read older saved files.
    private static final long serialVersionUID = 1L;

    // Using the exact variable names provided
    private String empName;
    private String empID;
    private String empPass; // Added to store employee login password
    private String empType; // e.g., "Regular", "Probational", "Contractual", "PartTimer"
    private double empMonthSalary;
    private double empHourSalary;
    private String cutoffPeriod;
    private double empLoan;

    // Constructor
    // ORIGINAL SIGNATURE: public Employee(String empName, String empID, String empType, double empMonthSalary, double empHourSalary, String cutoffPeriod, double empLoan)
    // UPDATE TO:
    public Employee(String empName, String empID, String empType, double empMonthSalary, 
                    double empHourSalary, String cutoffPeriod, double empLoan, String empPass) {
        this.empName = empName;
        this.empID = empID;
        // WHY: We initialize the new password field when creating the object
        this.empPass = empPass; 
        this.empType = empType;
        this.empMonthSalary = empMonthSalary;
        this.empHourSalary = empHourSalary;
        this.cutoffPeriod = cutoffPeriod;
        this.empLoan = empLoan;      
    }

    // Getters and Setters
    // WHY: We keep variables private to prevent accidental changes. 
    // Other classes must use these methods to interact with the data safely.

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpID() {
        return empID;
    }

    public void setEmpID(String empID) {
        this.empID = empID;
    }
    
    public String getEmpPass() {
        return empPass;
    }

    public void setEmpPass(String empPass) {
        this.empPass = empPass;
    }

    public String getEmpType() {
        return empType;
    }

    public void setEmpType(String empType) {
        this.empType = empType;
    }

    public double getEmpMonthSalary() {
        return empMonthSalary;
    }

    public void setEmpMonthSalary(double empMonthSalary) {
        this.empMonthSalary = empMonthSalary;
    }

    public double getEmpHourSalary() {
        return empHourSalary;
    }

    public void setEmpHourSalary(double empHourSalary) {
        this.empHourSalary = empHourSalary;
    }

    public String getCutoffPeriod() {
        return cutoffPeriod;
    }

    public void setCutoffPeriod(String cutoffPeriod) {
        this.cutoffPeriod = cutoffPeriod;
    }

    public double getEmpLoan() {
        return empLoan;
    }

    public void setEmpLoan(double empLoan) {
        this.empLoan = empLoan;
    }
}

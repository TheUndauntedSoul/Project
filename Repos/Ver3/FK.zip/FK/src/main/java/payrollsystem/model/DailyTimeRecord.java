package payrollsystem.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

public class DailyTimeRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private LocalDate date;
    private LocalTime timeIn;
    private LocalTime timeOut;
    private double totalHoursWorked;
    private double totalLate;      // Stored in hours or minutes (e.g., 1.5 for 1 hr 30 mins)
    private double totalUndertime;
    private double totalOvertime;

    public DailyTimeRecord(LocalDate date, LocalTime timeIn, LocalTime timeOut) {
        this.date = date;
        this.timeIn = timeIn;
        this.timeOut = timeOut;
        this.totalHoursWorked = 0.0;
        this.totalLate = 0.0;
        this.totalUndertime = 0.0;
        this.totalOvertime = 0.0;
    }

    // Getters
    public LocalDate getDate() { return date; }
    public LocalTime getTimeIn() { return timeIn; }
    public LocalTime getTimeOut() { return timeOut; }
    public double getTotalHoursWorked() { return totalHoursWorked; }
    public double getTotalLate() { return totalLate; }
    public double getTotalUndertime() { return totalUndertime; }
    public double getTotalOvertime() { return totalOvertime; }

    // Setters
    public void setDate(LocalDate date) { this.date = date; }
    public void setTimeIn(LocalTime timeIn) { this.timeIn = timeIn; }
    public void setTimeOut(LocalTime timeOut) { this.timeOut = timeOut; }
    public void setTotalHoursWorked(double totalHoursWorked) { this.totalHoursWorked = totalHoursWorked; }
    public void setTotalLate(double totalLate) { this.totalLate = totalLate; }
    public void setTotalUndertime(double totalUndertime) { this.totalUndertime = totalUndertime; }
    public void setTotalOvertime(double totalOvertime) { this.totalOvertime = totalOvertime; }
}

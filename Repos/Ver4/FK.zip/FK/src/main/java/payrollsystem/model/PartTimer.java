package payrollsystem.model;

public class PartTimer extends Employee {
    private static final long serialVersionUID = 1L;

    public PartTimer(String name, String id, String password, double hourlyRate, String cutoffPeriod) {
        super(name, id, password, "Part-Timer", hourlyRate, cutoffPeriod);
    }

    @Override
    public double calculateBasePay(double actualWorkedHours) {
        // Part-timers are paid strictly for hours worked multiplied by their hourly rate
        return actualWorkedHours * getSalaryRate();
    }
}
package payrollsystem.utils;

public class AttendanceCalculator {

    public static payrollsystem.model.AttendanceSummary calculateMetrics(
        payrollsystem.model.Employee emp, 
        java.util.List<payrollsystem.model.DailyTimeRecord> records) {
    
    double totalBasicHours = 0;
    double totalOtHours = 0;
    double totalLateUndertimeHours = 0;
    
    for (payrollsystem.model.DailyTimeRecord dtr : records) {
        
        // --- PAID LEAVE INJECTION (UPDATED WITH CONTRACTUAL RULE) ---
        String status = dtr.getStatus();
        if (status != null && (status.toUpperCase().contains("APPROVED") || status.toUpperCase().contains("PAID LEAVE"))) {
            
            // Check if the employee is Contractual
            if (emp instanceof payrollsystem.model.ContractualEmployee) {
                // Contractual employees do not have leave benefits. 
                // We do NOT add the 8.0 hours, treating it strictly as unpaid time off.
                continue; 
            } else {
                // Regular/Probationary employees receive full credit for the work day
                totalBasicHours += 8.0;
                continue; // Skip the rest of the time math for this day
            }
        }
            
            // 1. HOLIDAY FLAG INTEGRATION
            String holidayType = payrollsystem.utils.PhilippineHolidayService.getHolidayType(dtr.getDate());
            
            switch (holidayType) {
                case "REGULAR" -> {
                    dtr.setRegularHoliday(true);
                    dtr.setSpecialHoliday(false);
                }
                case "SPECIAL" -> {
                    dtr.setRegularHoliday(false);
                    dtr.setSpecialHoliday(true);
                }
                default -> {
                    dtr.setRegularHoliday(false);
                    dtr.setSpecialHoliday(false);
                }
            }

            // 2. TIME CALCULATIONS WITH SHIFT CLAMPING
            if (dtr.getTimeIn() != null && dtr.getTimeOut() != null) {
                
                // Define the strict shift boundaries
                java.time.LocalTime shiftStart = java.time.LocalTime.of(8, 0);
                java.time.LocalTime shiftEnd = java.time.LocalTime.of(17, 0); // 5:00 PM
                
                // --- A. CLAMP EARLY IN ---
                // If they clock in before 8:00 AM, payable time starts at 8:00 AM.
                java.time.LocalTime effectiveIn = dtr.getTimeIn();
                if (effectiveIn.isBefore(shiftStart)) {
                    effectiveIn = shiftStart;
                }

                // --- B. LATE PENALTY ---
                if (effectiveIn.isAfter(shiftStart)) {
                    long lateMinutes = java.time.temporal.ChronoUnit.MINUTES.between(shiftStart, effectiveIn);
                    if (lateMinutes > 0 && lateMinutes < 480) { 
                        totalLateUndertimeHours += (lateMinutes / 60.0);
                    }
                }

                // --- C. CLAMP AUTO-OT & CALCULATE APPROVED OT ---
                java.time.LocalTime effectiveOut = dtr.getTimeOut();
                double dailyOtHours = 0;

                if (effectiveOut.isAfter(shiftEnd)) {
                    // Check if Admin approved the overtime
                    if (dtr.isOtApproved()) {
                        long otMinutes = java.time.temporal.ChronoUnit.MINUTES.between(shiftEnd, effectiveOut);
                        dailyOtHours = otMinutes / 60.0;
                    }
                    
                    // Regardless of OT approval, we MUST clamp the effectiveOut to 5:00 PM 
                    // so the "Basic Pay" math below doesn't accidentally pay them twice for those hours.
                    effectiveOut = shiftEnd; 
                }

                // Prevent negative time if they came in early and left early
                if (effectiveOut.isBefore(effectiveIn)) {
                    effectiveOut = effectiveIn;
                }

                // --- D. PAYABLE MINUTES & LUNCH ---
                long payableMinutes = java.time.temporal.ChronoUnit.MINUTES.between(effectiveIn, effectiveOut);

                if (payableMinutes >= 300) { 
                    payableMinutes -= 60;
                }

                double basicHours = payableMinutes / 60.0;
                if (basicHours < 0) basicHours = 0;
                
                totalBasicHours += basicHours;
                totalOtHours += dailyOtHours; // Add the approved OT to the grand total
                
                // Note: totalOtHours remains 0 here because unapproved OT was clamped away.
            }
        }
        
        // Return the summary object
        return new payrollsystem.model.AttendanceSummary(totalBasicHours, totalOtHours, totalLateUndertimeHours);
    }
    
    // Add to AttendanceCalculator.java or PayrollCalculator.java
    public static int countAbsences(payrollsystem.model.Employee emp, int year, int month) {
    int absences = 0;
    
    // Loop ONLY through the records the employee actually has
    for (payrollsystem.model.DailyTimeRecord record : emp.getDtrRecords()) {
        
        // Ensure we are only checking the current month and year
        if (record.getDate().getYear() == year && record.getDate().getMonthValue() == month) {
            
            // If TimeIn is missing (null) OR TimeIn is exactly 00:00 (Midnight)
            if (record.getTimeIn() == null || record.getTimeIn().equals(java.time.LocalTime.MIDNIGHT)) {
                absences++;
            }
        }
    }
    
    return absences;
}
        
}
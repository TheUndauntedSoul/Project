package payrollsystem.utils;

public class PayrollCalculator {

    // SSS 2025: 15% Total (10% ER, 5% EE) 
    // Min MSC: 5,000 | Max MSC: 35,000
    public static double getSSSEmployeeShare(double monthlySalary) {
        double msc = Math.max(5000, Math.min(monthlySalary, 35000));
        return (msc * 0.05) / 2; // 5% EE share, halved for bi-monthly
    }

    // PhilHealth 2025-2026: 5% Total (2.5% ER, 2.5% EE)
    public static double getPhilHealthShare(double monthlySalary) {
        return (monthlySalary * 0.025) / 2; // 2.5% EE share, halved for bi-monthly
    }

    // Pag-IBIG: Fixed 200 total (100 ER, 100 EE)
    public static double getPagIBIGShare() {
        return 200.00 / 2; // Halved for bi-monthly
    }

    // BIR Semi-Monthly Tax Table (2023 onwards)
    public static double calculateTax(double taxableIncome) {
        if (taxableIncome <= 10417) {
            return 0;
        } else if (taxableIncome <= 16666) {
            return (taxableIncome - 10417) * 0.15;
        } else if (taxableIncome <= 33332) {
            return 937.50 + ((taxableIncome - 16667) * 0.20);
        } else if (taxableIncome <= 83332) {
            return 4270.70 + ((taxableIncome - 33333) * 0.25);
        } else if (taxableIncome <= 333332) {
            return 16770.70 + ((taxableIncome - 83333) * 0.30);
        } else {
            return 91770.70 + ((taxableIncome - 333333) * 0.35);
        }
    }
    
    // Overtime Rate: 1.25x of the hourly rate
    public static double calculateOvertimePay(double otHours, double hourlyRate) {
        return otHours * (hourlyRate * 1.25);
    }

    // Holiday Pay
    // Special Holiday: 1.30x | Regular Holiday: 2.00x
    public static double calculateHolidayPay(double hours, double hourlyRate, String holidayType) {
        if (holidayType.equalsIgnoreCase("REGULAR")) {
            return hours * (hourlyRate * 2.00);
        } else if (holidayType.equalsIgnoreCase("SPECIAL")) {
            return hours * (hourlyRate * 1.30);
        }
        return 0.0;
    }
    // --- ADD THIS METHOD ---
    public static double calculateRequiredMonthlyHours(int year, int month) {
        int workDays = 0;
        java.time.YearMonth ym = java.time.YearMonth.of(year, month);
        
        for (int i = 1; i <= ym.lengthOfMonth(); i++) {
            java.time.LocalDate date = ym.atDay(i);
            
            // Skip Weekends
            if (date.getDayOfWeek() == java.time.DayOfWeek.SATURDAY || 
                date.getDayOfWeek() == java.time.DayOfWeek.SUNDAY) {
                continue;
            }
            
            // Skip Holidays (Using the helper we added earlier)
            if (payrollsystem.utils.PhilippineHolidayService.isHoliday(date)) { 
                continue;
            }
            
            workDays++;
        }
        
        // Return total required hours (8 hours per working day)
        return workDays * 8.0;
    }
}
package payrollsystem.controller;

import payrollsystem.model.Employee;
import payrollsystem.utils.FileStorageManager;
import payrollsystem.view.LoginView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import payrollsystem.view.DashboardView;
import payrollsystem.controller.DashboardController;

public class LoginController {
    private LoginView view;
    private List<Employee> employeeDatabase;

    public LoginController(LoginView view) {
        this.view = view;
        // Load the database into memory upon controller initialization
        this.employeeDatabase = FileStorageManager.loadEmployees();
        initController();
    }

    private void initController() {
        // Attach the action listener to the button provided by the View
        this.view.getBtnLogin().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                authenticateUser();
            }
        });
    }

    private void authenticateUser() {
        // Retrieve inputs from the View
        String userId = view.getTxtUserId().getText().trim();
        String password = new String(view.getTxtPassword().getPassword());

        // 1. Check Hardcoded Admin Credentials
        if (userId.equals("admin") && password.equals("adminpass")) {
            JOptionPane.showMessageDialog(view, "Admin Authentication Successful.", "System Access", JOptionPane.INFORMATION_MESSAGE);
            launchDashboard(null, true);
            return;
        }

        // 2. Check Employee Database
        for (Employee emp : employeeDatabase) {
            if (emp.getId().equals(userId) && emp.getPassword().equals(password)) {
                JOptionPane.showMessageDialog(view, "Authentication Successful. Welcome, " + emp.getName(), "System Access", JOptionPane.INFORMATION_MESSAGE);
                launchDashboard(emp, false);
                return;
            }
        }

        // 3. Fallback for Invalid Credentials
        JOptionPane.showMessageDialog(view, "Invalid User ID or Password.", "Authentication Failed", JOptionPane.ERROR_MESSAGE);
    }

    private void launchDashboard(Employee loggedInUser, boolean isAdmin) {
        System.out.println("Authentication verified. Transitioning to Dashboard...");
        
        // 1. Close and dispose of the Login window
        view.setVisible(false);
        view.dispose();
        
        // 2. Instantiate the Dashboard View and Controller
        payrollsystem.view.DashboardView dashboardView = new payrollsystem.view.DashboardView();
        payrollsystem.controller.DashboardController dashController = new payrollsystem.controller.DashboardController(dashboardView, loggedInUser, isAdmin);
        
        // 3. Display the Dashboard
        dashboardView.pack();
        dashboardView.setLocationRelativeTo(null); // Center on screen
        dashboardView.setVisible(true);
    }
}

package PayrollV2;

// WHY: We import the LoginView so the Main class knows what to open first.
import PayrollV2.view.LoginView;

public class Main {

    public static void main(String[] args) {
        
        // 1. SET LOOK AND FEEL
        // WHY: This block applies the modern "Nimbus" theme standard to NetBeans GUI Builder.
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        // 2. LAUNCH THE APPLICATION
        // WHY: invokeLater ensures the GUI is created safely on the Event Dispatch Thread, 
        // preventing UI freezing or threading conflicts right at startup.
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                // Initialize the Login window and make it visible
                new LoginView().setVisible(true);
            }
        });
    }
}

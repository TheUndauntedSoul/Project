package payrollsystem.controller;

import payrollsystem.model.Employee;
import payrollsystem.model.DailyTimeRecord;
import payrollsystem.model.AttendanceSummary;
import payrollsystem.utils.AttendanceCalculator;
import payrollsystem.view.EmployeeDashboardView;
import payrollsystem.view.LoginView;

import javax.swing.Timer;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class EmployeeDashboardController {
    private EmployeeDashboardView view;
    private Employee loggedInEmployee;
    private List<Employee> employeeDatabase;
    private Timer clockTimer;

    public EmployeeDashboardController(EmployeeDashboardView view, Employee employee, List<Employee> database) {
        this.view = view;
        this.loggedInEmployee = employee;
        this.employeeDatabase = database;
        
        initController();
        startLiveClock();
        loadProfileData();
        
        // Start on Profile Panel by default
        switchPanel(view.getLay1());
    }

    private void initController() {
        // --- NAVIGATION ---
        view.getBtnMyProfile().addActionListener(e -> switchPanel(view.getLay1()));
        view.getBtnTimePuncher().addActionListener(e -> {
            switchPanel(view.getLay2());
            refreshTimekeepingPanel(); // Recalculate stats whenever they open this tab
        });
        view.getBtnMyPayslips().addActionListener(e -> switchPanel(view.getLay3()));
        view.getBtnLeaveRequests().addActionListener(e -> switchPanel(view.getLay4()));
        view.getBtnLogout().addActionListener(e -> logout());

        // --- ACTION BUTTONS ---
        view.getBtnPunchTime().addActionListener(e -> punchTime());
        // (Leave and Payslip listeners will be added here in the next steps)
    }

    // --- HELPER METHODS ---

    private void switchPanel(javax.swing.JPanel panel) {
        view.getLay1().setVisible(false);
        view.getLay2().setVisible(false);
        view.getLay3().setVisible(false);
        view.getLay4().setVisible(false);
        panel.setVisible(true);
    }

    private void startLiveClock() {
        clockTimer = new Timer(1000, e -> {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy  |  hh:mm:ss a");
            view.getLblLiveClock().setText(java.time.LocalDateTime.now().format(formatter));
        });
        clockTimer.start();
    }

    private void loadProfileData() {
        // Lock fields so the employee cannot give themselves a raise
        view.getTxtId().setEditable(false);
        view.getTxtName().setEditable(false);
        view.getTxtType().setEditable(false);
        view.getTxtSalary().setEditable(false);
        view.getTxtCutoff().setEditable(false);
        
        // Load data
        view.getTxtId().setText(loggedInEmployee.getId());
        view.getTxtName().setText(loggedInEmployee.getName());
        view.getTxtType().setText(loggedInEmployee.getEmployeeType());
        view.getTxtSalary().setText(String.valueOf(loggedInEmployee.getSalaryRate()));
        view.getTxtCutoff().setText(loggedInEmployee.getCutoffPeriod());
        view.getTxtPassword().setText(loggedInEmployee.getPassword());
    }

    private void refreshTimekeepingPanel() {
        LocalDate today = LocalDate.now();
        DailyTimeRecord todayRecord = getRecordByDate(today);

        // 1. Update the Dynamic Punch Button
        if (todayRecord == null || todayRecord.getTimeIn() == null) {
            view.getBtnPunchTime().setText("Punch In");
            view.getBtnPunchTime().setEnabled(true);
        } else if (todayRecord.getTimeOut() == null) {
            view.getBtnPunchTime().setText("Punch Out");
            view.getBtnPunchTime().setEnabled(true);
        } else {
            view.getBtnPunchTime().setText("Shift Completed");
            view.getBtnPunchTime().setEnabled(false); // Locked for the rest of the day
        }

        // 2. Populate the Table
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) view.getTableMyAttendance().getModel();
        model.setRowCount(0);
        
        for (DailyTimeRecord dtr : loggedInEmployee.getDtrRecords()) {
            String tIn = dtr.getTimeIn() != null ? dtr.getTimeIn().toString() : "--";
            String tOut = dtr.getTimeOut() != null ? dtr.getTimeOut().toString() : "--";
            
            String leaveStr = dtr.getStatus().contains("LEAVE") ? dtr.getStatus() : "No Leave";
            String otStr = dtr.isOtApproved() ? "OT Approved" : "No OT";
            String combinedStatus = "(" + leaveStr + ", " + otStr + ")";
            
            String dayType = "Regular";
            if (dtr.isRegularHoliday()) dayType = "Regular Holiday";
            else if (dtr.isSpecialHoliday()) dayType = "Special Non-Working";
            else if (dtr.isRestDay()) dayType = "Rest Day";

            model.addRow(new Object[]{dtr.getDate().toString(), tIn, tOut, combinedStatus, dayType});
        }

        // 3. Update the Live Stat Trackers using the Calculator Engine
        AttendanceSummary summary = AttendanceCalculator.calculateMetrics(loggedInEmployee, loggedInEmployee.getDtrRecords());
        
        view.getLblTotalHours().setText("Total Hours: " + String.format("%.2f", summary.getBasicWorkedHours()));
        view.getLblLateUndertime().setText("Late/Undertime: " + String.format("%.2f", summary.getLateUndertimeHours()));
        view.getLblAbsent().setText("Absences: " + summary.getTotalAbsences());
        view.getLblSickLeave().setText("Sick Leave Balance: " + loggedInEmployee.getSickLeaveBalance());
        view.getLblVacationLeave().setText("Vacation Balance: " + loggedInEmployee.getVacationLeaveBalance());
        view.getLblApprovedOt().setText("Approved OT: " + String.format("%.2f", summary.getRegularOtHours()));
    }

    private void punchTime() {
        LocalDate today = LocalDate.now();
        // Truncate to seconds so the saved time doesn't have massive decimal trails
        LocalTime now = LocalTime.now().truncatedTo(java.time.temporal.ChronoUnit.SECONDS); 
        DailyTimeRecord todayRecord = getRecordByDate(today);

        if (todayRecord == null) {
            // Logic for Punching In
            todayRecord = new DailyTimeRecord(today, now, null, "PRESENT");
            loggedInEmployee.getDtrRecords().add(todayRecord);
            javax.swing.JOptionPane.showMessageDialog(view, "Successfully Punched In at " + now);
        } else if (todayRecord.getTimeOut() == null) {
            // Logic for Punching Out
            todayRecord.setTimeOut(now);
            javax.swing.JOptionPane.showMessageDialog(view, "Successfully Punched Out at " + now);
        }

        // Save to file and instantly refresh the UI
        payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
        refreshTimekeepingPanel();
    }

    private DailyTimeRecord getRecordByDate(LocalDate date) {
        for (DailyTimeRecord dtr : loggedInEmployee.getDtrRecords()) {
            if (dtr.getDate().equals(date)) return dtr;
        }
        return null;
    }

    private void logout() {
        if (clockTimer != null) clockTimer.stop(); // Stop the thread to prevent memory leaks
        view.dispose();
        
        LoginView loginView = new LoginView();
        new LoginController(loginView);
        loginView.setLocationRelativeTo(null);
        loginView.setVisible(true);
    }
}
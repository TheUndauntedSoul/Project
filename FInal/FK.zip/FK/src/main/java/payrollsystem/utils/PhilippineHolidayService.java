package payrollsystem.utils;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

public class PhilippineHolidayService {
    private static Properties holidayProps = new Properties();

    static {
        try {
            // Load the file from the classpath
            InputStream is = PhilippineHolidayService.class.getClassLoader().getResourceAsStream("holidays.properties");
            if (is != null) {
                holidayProps.load(is);
            }
        } catch (IOException e) {
            System.err.println("Error loading holidays.properties: " + e.getMessage());
        }
    }

    public static String getHolidayType(LocalDate date) {
        String yyyyMMdd = date.toString(); // 2026-04-02
        String mmDd = date.format(DateTimeFormatter.ofPattern("MM-dd")); // 04-02

        // Check for specific date match first, then fixed date match
        if (holidayProps.containsKey(yyyyMMdd)) return holidayProps.getProperty(yyyyMMdd);
        if (holidayProps.containsKey(mmDd)) return holidayProps.getProperty(mmDd);
        
        return "NONE";
    }
    
    public static boolean isHoliday(LocalDate date) {
        // If the holiday type is not "NONE", then it is a holiday
        return !getHolidayType(date).equals("NONE");
    }
}
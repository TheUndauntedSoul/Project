package PayrollV2.controller;

import PayrollV2.model.Employee;
import PayrollV2.util.FileStorageUtil;
import java.io.IOException;

public class EmployeeController {

    // WHY: By keeping this logic here, the View (CreateEmployeePanel) doesn't need to know 
    // HOW saving works, it just passes the raw strings from the text fields.
    public boolean createAndSaveEmployee(String name, String id, String type, String monthSalStr, 
                                         String hourSalStr, String cutoff, String loanStr, String pass) {
        try {
            // WHY: Text fields return strings. We must parse them to doubles. 
            // We use ternary operators (condition ? true : false) to handle empty fields safely.
            double monthSal = monthSalStr.isEmpty() ? 0.0 : Double.parseDouble(monthSalStr);
            double hourSal = hourSalStr.isEmpty() ? 0.0 : Double.parseDouble(hourSalStr);
            double loan = loanStr.isEmpty() ? 0.0 : Double.parseDouble(loanStr);

            // Create the updated Employee object
            Employee newEmp = new Employee(name, id, type, monthSal, hourSal, cutoff, loan, pass);
            
            // WHY: We use the Employee ID as the file name (e.g., "1001_info.dat"). 
            // This makes it extremely easy for the Login sequence to find and verify the user later.
            String fileName = id + "_info.dat"; 
            FileStorageUtil.saveData(newEmp, fileName);
            
            return true; // Success
            
        } catch (NumberFormatException | IOException e) {
            // NumberFormatException happens if they type letters in the salary fields.
            // IOException happens if the file can't be written.
            e.printStackTrace();
            return false; // Failed
        }
    }
}
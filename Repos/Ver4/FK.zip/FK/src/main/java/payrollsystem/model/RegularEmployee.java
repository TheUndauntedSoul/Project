package payrollsystem.model;

public class RegularEmployee extends Employee {
    private static final long serialVersionUID = 1L;

    public RegularEmployee(String name, String id, String password, double salaryRate, String cutoffPeriod) {
        super(name, id, password, "Regular", salaryRate, cutoffPeriod);
    }

    @Override
    public double calculateBasePay(double actualWorkedHours) {
        // Regular employees receive their fixed period rate (salaryRate / 2)
        return getSalaryRate() / 2;
    }
}

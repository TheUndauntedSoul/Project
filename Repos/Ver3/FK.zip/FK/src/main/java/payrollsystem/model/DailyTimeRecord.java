package payrollsystem.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

public class DailyTimeRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private LocalDate date;
    private LocalTime timeIn;
    private LocalTime timeOut;
    private String status; // "PRESENT", "REST DAY", "LEAVE PENDING", "LEAVE APPROVED", "LEAVE DENIED", "INCOMPLETE PUNCH", "ABSENT"

    public DailyTimeRecord(LocalDate date, LocalTime timeIn, LocalTime timeOut, String status) {
        this.date = date;
        this.timeIn = timeIn;
        this.timeOut = timeOut;
        this.status = status;
    }

    public LocalDate getDate() { return date; }
    public LocalTime getTimeIn() { return timeIn; }
    public LocalTime getTimeOut() { return timeOut; }
    public String getStatus() { return status; }

    public void setDate(LocalDate date) { this.date = date; }
    public void setTimeIn(LocalTime timeIn) { this.timeIn = timeIn; }
    public void setTimeOut(LocalTime timeOut) { this.timeOut = timeOut; }
    public void setStatus(String status) { this.status = status; }
}

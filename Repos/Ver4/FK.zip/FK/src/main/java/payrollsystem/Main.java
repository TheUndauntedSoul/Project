package payrollsystem;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import payrollsystem.controller.LoginController; // Adjust if your package name is singular (controller)
import payrollsystem.view.LoginView;           // Adjust if your package name is singular (view)

public class Main {
    public static void main(String[] args) {
        /* Set the Nimbus look and feel for a modern UI look */
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | 
                 IllegalAccessException | UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName())
                .log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the application starting with the Gatekeeper */
        java.awt.EventQueue.invokeLater(() -> {
            // 1. Instantiate the View
            LoginView loginView = new LoginView();
            
            // 2. Instantiate the Controller and bind the View to it
            LoginController loginController = new LoginController(loginView);

            // 3. Display the View
            loginView.pack(); 
            loginView.setLocationRelativeTo(null); // Center on screen
            loginView.setVisible(true);
        });
    }
}
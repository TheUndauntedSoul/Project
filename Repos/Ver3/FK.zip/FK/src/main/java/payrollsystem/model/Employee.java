package payrollsystem.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Employee implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;           // Format: Last Name, First Name, Middle Initial, Suffix
    private String id;             // Format: XXXX-XXXX-XX
    private String password;
    private String employeeType;   // Regular, Probational, Contractual, Part-Timer
    private double salaryRate;     // Represents Monthly or Hourly depending on employeeType
    private String cutoffPeriod;   // "1st - 15th" or "16th - 30th"
    private double loanBalance;
    
    private List<DailyTimeRecord> dtrRecords;

    public Employee(String name, String id, String password, String employeeType, double salaryRate, String cutoffPeriod) {
        this.name = name;
        this.id = id;
        this.password = password;
        this.employeeType = employeeType;
        this.salaryRate = salaryRate;
        this.cutoffPeriod = cutoffPeriod;
        this.loanBalance = 0.0;
        this.dtrRecords = new ArrayList<>();
    }

    // Getters
    public String getName() { return name; }
    public String getId() { return id; }
    public String getPassword() { return password; }
    public String getEmployeeType() { return employeeType; }
    public double getSalaryRate() { return salaryRate; }
    public String getCutoffPeriod() { return cutoffPeriod; }
    public double getLoanBalance() { return loanBalance; }
    public List<DailyTimeRecord> getDtrRecords() { return dtrRecords; }

    // Setters
    public void setName(String name) { this.name = name; }
    public void setId(String id) { this.id = id; }
    public void setPassword(String password) { this.password = password; }
    public void setEmployeeType(String employeeType) { this.employeeType = employeeType; }
    public void setSalaryRate(double salaryRate) { this.salaryRate = salaryRate; }
    public void setCutoffPeriod(String cutoffPeriod) { this.cutoffPeriod = cutoffPeriod; }
    public void setLoanBalance(double loanBalance) { this.loanBalance = loanBalance; }
    public void setDtrRecords(List<DailyTimeRecord> dtrRecords) { this.dtrRecords = dtrRecords; }

    // Utility Method to add a single DTR entry
    public void addDailyTimeRecord(DailyTimeRecord dtr) {
        this.dtrRecords.add(dtr);
    }
    
    public double calculateBasePay(double actualWorkedHours) {
        return 0.0; // Overridden by subclasses
    }
    
}
    
    
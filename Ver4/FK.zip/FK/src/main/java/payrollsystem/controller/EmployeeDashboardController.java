package payrollsystem.controller;

import java.awt.HeadlessException;
import payrollsystem.model.Employee;
import payrollsystem.model.DailyTimeRecord;
import payrollsystem.model.AttendanceSummary;
import payrollsystem.utils.AttendanceCalculator;
import payrollsystem.view.EmployeeDashboardView;
import payrollsystem.view.LoginView;

import javax.swing.Timer;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class EmployeeDashboardController {
    private final EmployeeDashboardView view;
    private final Employee loggedInEmployee;
    private final List<Employee> employeeDatabase;
    private Timer clockTimer;
    // --- DEBUG TOOLING ---
    private payrollsystem.view.TestSeederDialog activeSeeder = null;

    public EmployeeDashboardController(EmployeeDashboardView view, Employee employee, List<Employee> database) {
        this.view = view;
        this.loggedInEmployee = employee;
        this.employeeDatabase = database;
        
        initController();
        startLiveClock();
        loadProfileData();
        
        // Start on Profile Panel by default
        switchPanel(view.getLay1());
        
        // DEBUG HARNESS: Set to false before presenting to your professor/client!
    boolean ENABLE_SEEDER = true; 
    if (ENABLE_SEEDER) {
        javax.swing.SwingUtilities.invokeLater(() -> launchDeveloperSeeder());
        }
    }

    private void initController() {
    view.getBtnMyProfile().addActionListener(e -> switchPanel(view.getLay1()));
    
    view.getBtnTimePuncher().addActionListener(e -> {
        switchPanel(view.getLay2());
        refreshTimekeepingPanel(); 
        refreshLeaveBalances();
    });
    
    view.getBtnLeaveRequest().addActionListener(e -> {
        switchPanel(view.getLay3()); 
        refreshLeaveBalances();      
    });
    
    view.getBtnMyPayslips().addActionListener(e -> {
    System.out.println("--- DEBUG: FORCING LAY 4 ---");
    
    // 1. Hide all others
    view.getLay1().setVisible(false);
    view.getLay2().setVisible(false);
    view.getLay3().setVisible(false);
    
    // 2. Force Lay 4
    view.getLay4().setVisible(true);
    view.getLay4().setBackground(java.awt.Color.MAGENTA); // BRIGHT PINK
    view.getLay4().setOpaque(true);
    
    // 3. Force to top of the stack
    java.awt.Container parent = view.getLay4().getParent();
    if (parent != null) {
        parent.setComponentZOrder(view.getLay4(), 0);
    }
    
    view.revalidate();
    view.repaint();
});
 

    view.getBtnLogout().addActionListener(e -> logout());

    // --- ACTION BUTTONS ---
    view.getBtnPunchTime().addActionListener(e -> punchTime());

    // --- PASSWORD UPDATE CONTROLS ---
    setupPlaceholder(view.getTxtUpdatePassword(), "Type new password here...");
    view.getBtnUpdatePassword().addActionListener(e -> updatePassword());
    view.getTxtUpdatePassword().addActionListener(e -> updatePassword()); 

    // --- LEAVE REQUEST ---
    setupPlaceholder(view.getTxtLeaveDate(), "YYYY-MM-DD");
    view.getBtnSubmitLeave().addActionListener(e -> submitLeaveRequest());

    // --- PAYSLIP VIEWING ---
    view.getBtnViewPayslip().addActionListener(e -> displaySelectedPayslip());

    // --- INITIAL STATE ---
    refreshPayslipArchive();
}

    // --- HELPER METHODS ---

    private void switchPanel(javax.swing.JPanel targetPanel) {
    // 1. Hide all panels
    view.getLay1().setVisible(false);
    view.getLay2().setVisible(false);
    view.getLay3().setVisible(false);
    view.getLay4().setVisible(false);

    // 2. Show the requested one
    targetPanel.setVisible(true);

    // 3. Refresh the view
    view.revalidate();
    view.repaint();
}

    private void startLiveClock() {
        clockTimer = new Timer(1000, e -> {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy  |  hh:mm:ss a");
            view.getLblLiveClock().setText(java.time.LocalDateTime.now().format(formatter));
        });
        clockTimer.start();
    }

    private void loadProfileData() {
        // Lock fields so the employee cannot edit their own profile
        view.getTxtId().setEditable(false);
        view.getTxtName().setEditable(false);
        view.getTxtType().setEditable(false);
        view.getTxtSalary().setEditable(false);
        view.getTxtCutoff().setEditable(false);
        view.getTxtMonthOf().setEditable(false); // NEW: Lock the month field
        
        
        // Fetch and format the current month and year (e.g., "MAY 2026")
        java.time.LocalDate now = java.time.LocalDate.now();
        String currentMonth = now.getMonth().name() + " " + now.getYear();
        
        // Load data into fields
        view.getTxtId().setText(loggedInEmployee.getId());
        view.getTxtName().setText(loggedInEmployee.getName());
        view.getTxtType().setText(loggedInEmployee.getEmployeeType());
        view.getTxtSalary().setText(String.valueOf(loggedInEmployee.getSalaryRate()));
        view.getTxtCutoff().setText(loggedInEmployee.getCutoffPeriod());
        view.getTxtPassword().setText(loggedInEmployee.getPassword());
        
        // Set the dynamic month
        view.getTxtMonthOf().setText(currentMonth);
        view.getTxtLoans().setText(String.format("%.2f", loggedInEmployee.getLoanBalance()));
    }

    private void refreshTimekeepingPanel() {
        LocalDate today = LocalDate.now();
        DailyTimeRecord todayRecord = getRecordByDate(today);
        DailyTimeRecord openRecord = getOpenTimeRecord(); // Check for midnight crossovers

        // 1. Update the Dynamic Punch Button
        if (openRecord != null) {
            // There is an active shift (from today OR yesterday) waiting to be closed
            view.getBtnPunchTime().setText("Punch Out");
            view.getBtnPunchTime().setEnabled(true);
        } else if (todayRecord == null || todayRecord.getTimeIn() == null) {
            // No active shift, and today hasn't been started
            view.getBtnPunchTime().setText("Punch In");
            view.getBtnPunchTime().setEnabled(true);
        } else {
            // Shift completed for today
            view.getBtnPunchTime().setText("Shift Completed");
            view.getBtnPunchTime().setEnabled(false);
        }

        // 2. Populate the Table (UPGRADED PRE-FILL LOGIC)
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) view.getTableMyAttendance().getModel();
        model.setRowCount(0);

        int year = java.time.LocalDate.now().getYear(); 
        int month = java.time.LocalDate.now().getMonthValue(); 
        
        String cutoff = loggedInEmployee.getCutoffPeriod();
        int startDay = (cutoff != null && cutoff.startsWith("16th")) ? 16 : 1;
        int endDay = (startDay == 1) ? 15 : java.time.YearMonth.of(year, month).lengthOfMonth();

        for (int i = startDay; i <= endDay; i++) {
            java.time.LocalDate date = java.time.LocalDate.of(year, month, i);
            DailyTimeRecord matchingDtr = getRecordByDate(date);
            String dayStr = date.toString();
            
            if (matchingDtr != null) {
                // Show existing records
                String tIn = matchingDtr.getTimeIn() != null ? matchingDtr.getTimeIn().toString() : "--";
                String tOut = matchingDtr.getTimeOut() != null ? matchingDtr.getTimeOut().toString() : "--";
                
                String leaveStr = matchingDtr.getStatus().contains("LEAVE") ? matchingDtr.getStatus() : "No Leave";
                String otStr = matchingDtr.isOtApproved() ? "OT Approved" : "No OT";
                String combinedStatus = "(" + leaveStr + ", " + otStr + ")";
                
                String dayType = "Regular";
                if (matchingDtr.isRegularHoliday()) dayType = "Regular Holiday";
                else if (matchingDtr.isSpecialHoliday()) dayType = "Special Non-Working";
                else if (matchingDtr.isRestDay()) dayType = "Rest Day";

                model.addRow(new Object[]{dayStr, tIn, tOut, combinedStatus, dayType});
            } else {
                // Show blank rows with auto-detected weekends
                java.time.DayOfWeek dow = date.getDayOfWeek();
                String defaultDayType = (dow == java.time.DayOfWeek.SATURDAY || dow == java.time.DayOfWeek.SUNDAY) ? "Rest Day" : "Regular";
                model.addRow(new Object[]{dayStr, "--", "--", "NO RECORD", defaultDayType});
            }
        }

        // 3. Update the Live Stat Trackers using the Calculator Engine
        AttendanceSummary summary = AttendanceCalculator.calculateMetrics(loggedInEmployee, loggedInEmployee.getDtrRecords());
        
        view.getLblTotalHours().setText("Total Hours: " + String.format("%.2f", summary.getBasicWorkedHours()));
        view.getLblLateUndertime().setText("Late/Undertime: " + String.format("%.2f", summary.getLateUndertimeHours()));
        view.getLblAbsent().setText("Absences: " + summary.getTotalAbsences());
        view.getLblSickLeave().setText("Sick Leave Balance: " + loggedInEmployee.getSickLeaveBalance());
        view.getLblVacationLeave().setText("Vacation Balance: " + loggedInEmployee.getVacationLeaveBalance());
        view.getLblApprovedOt().setText("Approved OT: " + String.format("%.2f", summary.getRegularOtHours()));
    }

    private void punchTime() {
    LocalDate today = LocalDate.now();
    LocalTime now = LocalTime.now().truncatedTo(java.time.temporal.ChronoUnit.SECONDS);

    // --- NEW: WEEKEND LOCKOUT ---
    java.time.DayOfWeek dayOfWeek = today.getDayOfWeek();
    if (dayOfWeek == java.time.DayOfWeek.SATURDAY || dayOfWeek == java.time.DayOfWeek.SUNDAY) {
        javax.swing.JOptionPane.showMessageDialog(view, 
            "System Lock: You cannot punch in or out on weekends.", 
            "Weekend Restricted", javax.swing.JOptionPane.ERROR_MESSAGE);
        return; 
    }
        
    // --- 1. STRICT CUTOFF VALIDATOR ---
    int currentDay = today.getDayOfMonth();
    String cutoff = loggedInEmployee.getCutoffPeriod();
    boolean isValidCutoff = false;
        
    if (cutoff != null && cutoff.startsWith("16th")) {
        if (currentDay >= 16) isValidCutoff = true;
    } else {
        if (currentDay >= 1 && currentDay <= 15) isValidCutoff = true;
    }

    if (!isValidCutoff) {
        javax.swing.JOptionPane.showMessageDialog(view, 
            "Action Denied: Today's date (" + today + ") is outside your active cutoff period (" + cutoff + ").", 
            "Cutoff Validation Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        return; 
    }
    // ----------------------------------

    DailyTimeRecord openRecord = getOpenTimeRecord();

    if (openRecord != null) {
        // --- 1. TIME TRAVEL GUARD ---
        if (now.isBefore(openRecord.getTimeIn())) {
             javax.swing.JOptionPane.showMessageDialog(view, "System Error: Punch out time cannot be earlier than your punch in time.", "Time Travel Detected", javax.swing.JOptionPane.ERROR_MESSAGE);
             return;
        }

        // --- GHOST SHIFT DETECTOR ---
        long daysPassed = java.time.temporal.ChronoUnit.DAYS.between(openRecord.getDate(), today);
        
        if (daysPassed >= 1 && (now.isAfter(loggedInEmployee.getShiftStartTime()) || daysPassed > 1)) {
            openRecord.setStatus("INVALID: MISSED PUNCH OUT");
            javax.swing.JOptionPane.showMessageDialog(view, 
                "System Alert: You failed to punch out of a previous shift.\nThat shift has been flagged for Admin review.", 
                "Missed Punch Detected", javax.swing.JOptionPane.WARNING_MESSAGE);
            
            DailyTimeRecord todayRecord = getRecordByDate(today);
            if (todayRecord == null) {
                todayRecord = new DailyTimeRecord(today, now, null, "PRESENT");
                loggedInEmployee.getDtrRecords().add(todayRecord);
                javax.swing.JOptionPane.showMessageDialog(view, "Successfully Punched In for TODAY at " + now);
            }
        } else {
            // --- 2. NEXT SHIFT BOUNDARY GATEKEEPER ---
            LocalTime boundary = loggedInEmployee.getShiftStartTime().minusHours(1);
            if (now.isAfter(boundary) && now.isBefore(loggedInEmployee.getShiftStartTime().plusHours(1))) {
                openRecord.setStatus("FLAGGED: SHIFT OVERLAP");
                javax.swing.JOptionPane.showMessageDialog(view, 
                    "System Alert: Punch out is too close to your next shift start.\nThis record has been flagged for Admin review.", 
                    "Shift Boundary Exceeded", javax.swing.JOptionPane.WARNING_MESSAGE);
            }

            // LOGIC: NORMAL PUNCH OUT
            openRecord.setTimeOut(now);
            javax.swing.JOptionPane.showMessageDialog(view, "Successfully Punched Out at " + now);
        }
        
    } else {
        // LOGIC: NORMAL PUNCH IN
        DailyTimeRecord todayRecord = getRecordByDate(today);
        
        if (todayRecord != null && todayRecord.getTimeOut() != null) {
            javax.swing.JOptionPane.showMessageDialog(view, "You have already completed your shift for today.", "Action Denied", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        todayRecord = new DailyTimeRecord(today, now, null, "PRESENT");
        loggedInEmployee.getDtrRecords().add(todayRecord);
        javax.swing.JOptionPane.showMessageDialog(view, "Successfully Punched In at " + now);
    }

    // Save to file and instantly refresh the UI
    payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
    refreshTimekeepingPanel();
}

    private void logout() {
    if (clockTimer != null) clockTimer.stop(); // Stop the thread to prevent memory leaks
    
    // --- NEW: CLOSE THE FLOATING SEEDER ---
    if (activeSeeder != null) {
        activeSeeder.dispose(); // Destroys the window
        activeSeeder = null;    // Clears the memory reference
    }
    // --------------------------------------
    
    view.dispose(); // Close main dashboard
    
    payrollsystem.view.LoginView loginView = new payrollsystem.view.LoginView();
    new payrollsystem.controller.LoginController(loginView);
    loginView.setLocationRelativeTo(null);
    loginView.setVisible(true);
}
    
    // --- LEAVE SUBMISSION LOGIC ---
    private void submitLeaveRequest() {
        // 1. Get user input (Adjust these getters to match your actual UI names!)
        String dateStr = view.getTxtLeaveDate().getText().trim(); 
        String leaveType = view.getCmbLeaveType().getSelectedItem().toString().toUpperCase(); 
        
        // 2. Validate Date Format (Must be YYYY-MM-DD)
        java.time.LocalDate requestDate;
        try {
            requestDate = java.time.LocalDate.parse(dateStr);
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(view, "Invalid date format. Please use YYYY-MM-DD.");
            return;
        }
        
        if (requestDate.isBefore(java.time.LocalDate.now())) {
            javax.swing.JOptionPane.showMessageDialog(view, "Request Denied: Cannot request leave for a past date.");
            return;
        }
        
        // 3. Balance Validation Check
        if (leaveType.contains("SICK") && loggedInEmployee.getSickLeaveBalance() <= 0) {
            javax.swing.JOptionPane.showMessageDialog(view, "Request Denied: You have 0 Sick Leave days remaining.");
            return;
        } else if (leaveType.contains("VACATION") && loggedInEmployee.getVacationLeaveBalance() <= 0) {
            javax.swing.JOptionPane.showMessageDialog(view, "Request Denied: You have 0 Vacation Leave days remaining.");
            return;
        }
        
        // 4. Duplicate Request Check (Ensure they haven't already applied for this day)
        for (payrollsystem.model.DailyTimeRecord dtr : loggedInEmployee.getDtrRecords()) {
            if (dtr.getDate().equals(requestDate)) {
                javax.swing.JOptionPane.showMessageDialog(view, "Request Denied: A time record or leave request already exists for this date.");
                return;
            }
        }
        
        // 5. Create the "Ghost" DTR
        payrollsystem.model.DailyTimeRecord pendingLeave = new payrollsystem.model.DailyTimeRecord(
            requestDate, 
            null, // No Time In
            null, // No Time Out
            leaveType + " PENDING" // e.g., "SICK LEAVE PENDING"
        );
        
        // Add to local memory
        loggedInEmployee.getDtrRecords().add(pendingLeave);
        
        // 6. THE CRITICAL FIX: Save to Disk
        // We must load the master list, replace the old version of this employee with the updated one, and save.
        java.util.List<payrollsystem.model.Employee> masterDatabase = payrollsystem.utils.FileStorageManager.loadEmployees();
        
        for (int i = 0; i < masterDatabase.size(); i++) {
            if (masterDatabase.get(i).getId().equals(loggedInEmployee.getId())) {
                masterDatabase.set(i, loggedInEmployee); // Inject the updated profile
                break;
            }
        }
        
        payrollsystem.utils.FileStorageManager.saveEmployees(masterDatabase); // Write to employees.dat
        
        // 7. Success Feedback
        javax.swing.JOptionPane.showMessageDialog(view, "Leave request submitted successfully. Awaiting Admin approval.");
        view.getTxtLeaveDate().setText(""); // Clear the form
    }
    
    private DailyTimeRecord getRecordByDate(LocalDate date) {
        for (DailyTimeRecord dtr : loggedInEmployee.getDtrRecords()) {
            if (dtr.getDate().equals(date)) return dtr;
        }
        return null;
    }
    
    // --- MIDNIGHT CROSSING HELPER ---
    private DailyTimeRecord getOpenTimeRecord() {
        // 1. Check if TODAY has an open shift (Punched In, but not Out)
        DailyTimeRecord todayRec = getRecordByDate(LocalDate.now());
        if (todayRec != null && todayRec.getTimeIn() != null && todayRec.getTimeOut() == null) {
            return todayRec;
        }
        
        // 2. Check if YESTERDAY has an open shift (They worked past midnight!)
        DailyTimeRecord yesterdayRec = getRecordByDate(LocalDate.now().minusDays(1));
        if (yesterdayRec != null && yesterdayRec.getTimeIn() != null && yesterdayRec.getTimeOut() == null) {
            return yesterdayRec;
        }
        
        return null; // No open shifts found
    }
    
    // --- PASSWORD UPDATE LOGIC ---
    private void updatePassword() {
        // Grab the text from your dedicated new password field
        String newPassword = view.getTxtUpdatePassword().getText().trim();

        // 1. Validate Input
        if (newPassword.isEmpty() || newPassword.equals("Type new password here...")) {
            javax.swing.JOptionPane.showMessageDialog(view, 
                "Please enter a valid new password before updating.", 
                "Validation Error", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. The "Are You Sure?" Confirmation
        int confirm = javax.swing.JOptionPane.showConfirmDialog(view, 
            "Are you sure you want to change your password to this new value?", 
            "Confirm Password Change", 
            javax.swing.JOptionPane.YES_NO_OPTION,
            javax.swing.JOptionPane.QUESTION_MESSAGE);

        // 3. Execution
        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            loggedInEmployee.setPassword(newPassword);
            
            payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
            
            // ---> THE FIX: Update the display field with the new password <---
            view.getTxtPassword().setText(newPassword); 
            
            javax.swing.JOptionPane.showMessageDialog(view, 
                "Password updated successfully!", 
                "Security Update", 
                javax.swing.JOptionPane.INFORMATION_MESSAGE);
            
            // Reset the dedicated input field back to the placeholder state
            view.getTxtUpdatePassword().setText("");
            setupPlaceholder(view.getTxtUpdatePassword(), "Type new password here...");
            
            // Move the cursor focus away so the placeholder visually reappears
            view.getBtnUpdatePassword().requestFocusInWindow();
        }
    }
    
    // --- UI HELPER: PLACEHOLDER LOGIC ---
    private void setupPlaceholder(javax.swing.JTextField textField, String placeholderText) {
        // 1. Set the initial placeholder state if the field is empty
        if (textField.getText().isEmpty()) {
            textField.setForeground(java.awt.Color.GRAY);
            textField.setText(placeholderText);
        }

        // 2. Add the listener to detect when the user clicks in and out
        textField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                // When they click IN, clear the placeholder text
                if (textField.getText().equals(placeholderText)) {
                    textField.setText("");
                    textField.setForeground(java.awt.Color.BLACK); // Set to normal typing color
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                // When they click OUT, restore the placeholder if they typed nothing
                if (textField.getText().isEmpty()) {
                    textField.setForeground(java.awt.Color.GRAY);
                    textField.setText(placeholderText);
                }
            }
        });
    }
    
    // --- PAYSLIP ARCHIVE LOGIC ---

    private void refreshPayslipArchive() {
        // Clear old data
        view.getCmbPayslipDates().removeAllItems();
        view.getTxtPayslipViewer().setText("Select a date and click 'View' to securely open your payslip.");
        
        // Ensure the JTextArea uses a monospaced font so the formatting aligns perfectly
        view.getTxtPayslipViewer().setFont(new java.awt.Font("Consolas", java.awt.Font.PLAIN, 12));
        view.getTxtPayslipViewer().setEditable(false); // Lock it so they can't edit their pay!

        java.util.List<payrollsystem.model.PayslipRecord> payslips = loggedInEmployee.getPayslips();
        
        if (payslips == null || payslips.isEmpty()) {
            view.getCmbPayslipDates().addItem("No payslips available yet");
            view.getBtnViewPayslip().setEnabled(false);
            return;
        }

        // Enable button and populate dates
        // Enable button and populate dates with a clean format
        view.getBtnViewPayslip().setEnabled(true);
        
        // Formatter to make the date look like "May 15, 2026"
        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("MMM dd, yyyy");
        
        for (payrollsystem.model.PayslipRecord record : payslips) {
            String formattedDate = record.getDate().format(formatter);
            // Example output: "May 15, 2026 (Net: PHP 13,500.00)"
            String comboText = String.format("%s (Net: PHP %,.2f)", formattedDate, record.getNetPay());
            
            view.getCmbPayslipDates().addItem(comboText);
        }
    }

    private void displaySelectedPayslip() {
        int selectedIndex = view.getCmbPayslipDates().getSelectedIndex();
        java.util.List<payrollsystem.model.PayslipRecord> payslips = loggedInEmployee.getPayslips();

        // Check if the selection is valid
        if (selectedIndex >= 0 && payslips != null && selectedIndex < payslips.size()) {
            payrollsystem.model.PayslipRecord selectedRecord = payslips.get(selectedIndex);
            
            // Push the saved waterfall format to the screen
            // NOTE: Change 'getPayslipText()' to whatever your getter is named in PayslipRecord.java 
            // (e.g., getBreakdown(), getDetails(), etc.)
            view.getTxtPayslipViewer().setText(selectedRecord.getPayslipText());
            
            // Scroll to the top of the text area automatically
            view.getTxtPayslipViewer().setCaretPosition(0); 
        }
    }
    // --- LEAVE BALANCE DISPLAY LOGIC ---
    private void refreshLeaveBalances() {
        // Check if the labels exist to avoid NullPointerExceptions
        if (view.getLblSickLeave() != null) {
            view.getLblSickLeave().setText("Sick Leave Balance: " + loggedInEmployee.getSickLeaveBalance());
        }
        if (view.getLblVacationLeave() != null) {
            view.getLblVacationLeave().setText("Vacation Balance: " + loggedInEmployee.getVacationLeaveBalance());
        }
    }
    
    private void launchDeveloperSeeder() {
    // 1. Generate the Dates for the Dropdown based on current month/cutoff
    int year = java.time.LocalDate.now().getYear(); 
    int month = java.time.LocalDate.now().getMonthValue(); 
    int daysInMonth = java.time.YearMonth.of(year, month).lengthOfMonth();
    
    java.util.List<String> dates = new java.util.ArrayList<>();
    for (int i = 1; i <= daysInMonth; i++) {
        dates.add(java.time.LocalDate.of(year, month, i).toString());
    }

    // --- 2. LAUNCH UI (Now safely tracked by activeSeeder variable) ---
    activeSeeder = new payrollsystem.view.TestSeederDialog(null, dates.toArray(new String[0]));
    activeSeeder.setLocationRelativeTo(view); 
    activeSeeder.setLocation(view.getX() + view.getWidth() - 100, view.getY() + 100);
    activeSeeder.setVisible(true);

    // 3. The Execution Logic
    activeSeeder.getBtnApply().addActionListener(e -> {
        try {
            java.time.LocalDate start = java.time.LocalDate.parse(activeSeeder.getStartDate());
            java.time.LocalDate end = java.time.LocalDate.parse(activeSeeder.getEndDate());
            String scenario = activeSeeder.getScenario();
            java.util.Random random = new java.util.Random();

            // Validate Range
            if (start.isAfter(end)) {
                javax.swing.JOptionPane.showMessageDialog(activeSeeder, "Start date cannot be after end date!");
                return;
            }

            int recordsAdded = 0;

            // Loop through the selected date range
            for (java.time.LocalDate d = start; !d.isAfter(end); d = d.plusDays(1)) {
                
                // (The Lambda Fix: Freeze the date for this specific loop cycle)
                final java.time.LocalDate currentDate = d; 
                
                // Safely ignore weekends
                java.time.DayOfWeek dow = currentDate.getDayOfWeek();
                if (dow == java.time.DayOfWeek.SATURDAY || dow == java.time.DayOfWeek.SUNDAY) continue;

                // Determine variables based on Scenario
                java.time.LocalTime tIn = null;
                java.time.LocalTime tOut = null;
                String status = activeSeeder.getStatus();

                if (scenario.equals("Mixed (Work + Leaves)")) {
                    int chance = random.nextInt(100);
                    if (chance < 80) {
                        tIn = java.time.LocalTime.of(8, 0); tOut = java.time.LocalTime.of(17, 0); status = "PRESENT";
                    } else if (chance < 90) {
                        status = "SICK LEAVE APPROVED";
                    } else {
                        status = "VACATION LEAVE APPROVED";
                    }
                } else if (!scenario.equals("Absence Streak")) {
                    tIn = java.time.LocalTime.parse(activeSeeder.getTimeIn());
                    tOut = java.time.LocalTime.parse(activeSeeder.getTimeOut());
                }

                // Inject the record (Remove old record if it exists to overwrite cleanly)
                loggedInEmployee.getDtrRecords().removeIf(record -> record.getDate().equals(currentDate));
                
                payrollsystem.model.DailyTimeRecord newDtr = new payrollsystem.model.DailyTimeRecord(currentDate, tIn, tOut, status);
                loggedInEmployee.getDtrRecords().add(newDtr);
                recordsAdded++;
            }

            // Save and Refresh
            payrollsystem.utils.FileStorageManager.saveEmployees(employeeDatabase);
            refreshTimekeepingPanel();
            
            javax.swing.JOptionPane.showMessageDialog(activeSeeder, "Successfully seeded " + recordsAdded + " records.");

        } catch (HeadlessException ex) {
            javax.swing.JOptionPane.showMessageDialog(activeSeeder, "Error parsing time. Ensure format is HH:mm (e.g., 08:00)", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    });
}
}
    
    
    
    

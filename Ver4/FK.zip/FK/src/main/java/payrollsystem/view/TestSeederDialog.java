package payrollsystem.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class TestSeederDialog extends JDialog {

    private JComboBox<String> cmbStartDate;
    private JComboBox<String> cmbEndDate;
    private JComboBox<String> cmbScenario;
    private JTextField txtTimeIn;
    private JTextField txtTimeOut;
    private JComboBox<String> cmbStatus;
    private JButton btnApply;

    public TestSeederDialog(Frame parent, String[] cutoffDates) {
        // Set up the floating dialog (false = non-modal, so you can click the main app while this is open)
        super(parent, "⚡ Developer Seeder Tool", false);
        setSize(350, 320);
        setAlwaysOnTop(true);
        setResizable(false);
        
        // Main Container with padding
        JPanel mainPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        // 1. Initialize Components
        cmbStartDate = new JComboBox<>(cutoffDates);
        cmbEndDate = new JComboBox<>(cutoffDates);
        
        String[] scenarios = {"Custom Input", "Perfect Attendance", "Chronic Late", "All Overtime", "Absence Streak", "Mixed (Work + Leaves)"};
        cmbScenario = new JComboBox<>(scenarios);
        
        txtTimeIn = new JTextField("08:00");
        txtTimeOut = new JTextField("17:00");
        
        cmbStatus = new JComboBox<>(new String[]{"PRESENT", "ABSENT", "SICK LEAVE APPROVED", "VACATION LEAVE APPROVED"});
        
        btnApply = new JButton("Seed Data");
        btnApply.setBackground(new Color(46, 204, 113)); // A nice green button
        btnApply.setForeground(Color.WHITE);
        btnApply.setFocusPainted(false);
        btnApply.setFont(new Font("Arial", Font.BOLD, 14));

        // 2. Add Smart Listener to Scenario Dropdown
        cmbScenario.addActionListener(e -> applyScenarioPresets());

        // 3. Add to Panel
        mainPanel.add(new JLabel("Start Date:"));     mainPanel.add(cmbStartDate);
        mainPanel.add(new JLabel("End Date:"));       mainPanel.add(cmbEndDate);
        mainPanel.add(new JLabel("Scenario:"));       mainPanel.add(cmbScenario);
        mainPanel.add(new JLabel("Time In (HH:mm):"));mainPanel.add(txtTimeIn);
        mainPanel.add(new JLabel("Time Out (HH:mm):"));mainPanel.add(txtTimeOut);
        mainPanel.add(new JLabel("Status:"));         mainPanel.add(cmbStatus);
        mainPanel.add(new JLabel(""));                mainPanel.add(btnApply);

        add(mainPanel);
    }

    // --- SMART PRESET LOGIC ---
    private void applyScenarioPresets() {
        String scenario = cmbScenario.getSelectedItem().toString();
        boolean isCustom = scenario.equals("Custom Input");
        
        // Lock or unlock text fields based on selection
        txtTimeIn.setEnabled(isCustom);
        txtTimeOut.setEnabled(isCustom);
        cmbStatus.setEnabled(isCustom);

        switch (scenario) {
            case "Perfect Attendance":
                txtTimeIn.setText("08:00"); txtTimeOut.setText("17:00"); cmbStatus.setSelectedItem("PRESENT");
                break;
            case "Chronic Late":
                txtTimeIn.setText("09:30"); txtTimeOut.setText("17:00"); cmbStatus.setSelectedItem("PRESENT");
                break;
            case "All Overtime":
                txtTimeIn.setText("08:00"); txtTimeOut.setText("20:00"); cmbStatus.setSelectedItem("PRESENT");
                break;
            case "Absence Streak":
                txtTimeIn.setText("--:--"); txtTimeOut.setText("--:--"); cmbStatus.setSelectedItem("ABSENT");
                break;
            case "Mixed (Work + Leaves)":
                txtTimeIn.setText("Auto"); txtTimeOut.setText("Auto"); cmbStatus.setSelectedItem("PRESENT");
                break;
        }
    }

    // --- GETTERS FOR CONTROLLER ---
    public JButton getBtnApply() { return btnApply; }
    public String getStartDate() { return cmbStartDate.getSelectedItem().toString(); }
    public String getEndDate() { return cmbEndDate.getSelectedItem().toString(); }
    public String getScenario() { return cmbScenario.getSelectedItem().toString(); }
    public String getTimeIn() { return txtTimeIn.getText(); }
    public String getTimeOut() { return txtTimeOut.getText(); }
    public String getStatus() { return cmbStatus.getSelectedItem().toString(); }
}

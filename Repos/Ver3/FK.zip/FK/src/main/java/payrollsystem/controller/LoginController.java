package payrollsystem.controller;

import payrollsystem.model.Employee;
import payrollsystem.utils.FileStorageManager;
import payrollsystem.view.LoginView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import payrollsystem.view.EmployerDashboardView;
import payrollsystem.controller.EmployerDashboardController;

public class LoginController {
    private LoginView view;
    private List<Employee> employeeDatabase;

    public LoginController(LoginView view) {
        this.view = view;
        // Load the database into memory upon controller initialization
        this.employeeDatabase = FileStorageManager.loadEmployees();
        initController();
    }

    private void initController() {
        // Attach the action listener to the button provided by the View
        this.view.getBtnLogin().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                authenticateUser();
            }
        });
    }

    private void authenticateUser() {
        
        String id = view.getTxtId().getText().trim();
        String pass = new String(view.getTxtPassword().getPassword()).trim();

        // Prevent the system from treating the placeholders as real credentials
        if (id.equalsIgnoreCase("Enter Employee ID...") || pass.equalsIgnoreCase("Enter Password...")) {
            javax.swing.JOptionPane.showMessageDialog(view, "Please enter your ID and Password to login.");
            return; // Stop the login process immediately
        }
        
        // Retrieve inputs from the View
        String userId = view.getTxtUserId().getText().trim();
        String password = new String(view.getTxtPassword().getPassword());

        // 1. Check Hardcoded Admin Credentials
        if (userId.equals("admin") && password.equals("adminpass")) {
            JOptionPane.showMessageDialog(view, "Admin Authentication Successful.", "System Access", JOptionPane.INFORMATION_MESSAGE);
            launchDashboard(null, true);
            return;
        }

        // 2. Check Employee Database
        for (Employee emp : employeeDatabase) {
            if (emp.getId().equals(userId) && emp.getPassword().equals(password)) {
                JOptionPane.showMessageDialog(view, "Authentication Successful. Welcome, " + emp.getName(), "System Access", JOptionPane.INFORMATION_MESSAGE);
                launchDashboard(emp, false);
                return;
            }
        }

        // 3. Fallback for Invalid Credentials
        JOptionPane.showMessageDialog(view, "Invalid User ID or Password.", "Authentication Failed", JOptionPane.ERROR_MESSAGE);
    }

    private void launchDashboard(Employee loggedInUser, boolean isAdmin) {
        System.out.println("Authentication verified. Transitioning to Dashboard...");
        
        try {
            // 1. Instantiate and render the Dashboard FIRST to keep the JVM alive
            payrollsystem.view.EmployerDashboardView dashboardView = new payrollsystem.view.EmployerDashboardView();
            payrollsystem.controller.EmployerDashboardController dashController = new payrollsystem.controller.EmployerDashboardController(dashboardView, loggedInUser, isAdmin);
            
            dashboardView.pack();
            dashboardView.setLocationRelativeTo(null); 
            dashboardView.setVisible(true);
            
            // 2. ONLY THEN close and dispose of the Login window
            view.setVisible(false);
            view.dispose();
            
        } catch (Exception e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(null, 
                "Critical Error loading Dashboard:\n" + e.toString(), 
                "System Error", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
}
   
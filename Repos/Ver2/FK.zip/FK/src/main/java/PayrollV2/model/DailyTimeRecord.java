package PayrollV2.model;

import java.io.Serializable;

// WHY: Implements Serializable so an array or list of these records can be saved 
// directly to a file (e.g., "1001_time_records.dat") using our FileStorageUtil.
public class DailyTimeRecord implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private String empID;
    private String date; // e.g., "2026-05-01"
    private String timeIn; 
    private String timeOut;
    private String leaveStatus; // e.g., "NONE", "PENDING", "APPROVED", "DENIED"

    // Constructor
    // WHY: We initialize timeIn and timeOut as "Not Logged" by default so the table 
    // doesn't show null errors before the employee actually punches in.
    public DailyTimeRecord(String empID, String date) {
        this.empID = empID;
        this.date = date;
        this.timeIn = "Not Logged";
        this.timeOut = "Not Logged";
        this.leaveStatus = "NONE";
    }

    // Getters and Setters
    public String getEmpID() {
        return empID;
    }

    public void setEmpID(String empID) {
        this.empID = empID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTimeIn() {
        return timeIn;
    }

    public void setTimeIn(String timeIn) {
        this.timeIn = timeIn;
    }

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

    public String getLeaveStatus() {
        return leaveStatus;
    }

    public void setLeaveStatus(String leaveStatus) {
        this.leaveStatus = leaveStatus;
    }
}
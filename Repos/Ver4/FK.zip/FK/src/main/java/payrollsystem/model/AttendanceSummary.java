package payrollsystem.model;

public class AttendanceSummary {
    private double basicWorkedHours = 0.0;
    private double lateUndertimeHours = 0.0;
    private double regularOtHours = 0.0;
    private double restDayHours = 0.0;
    private double specialHolidayHours = 0.0;
    private double regularHolidayHours = 0.0;
    private double nsdHours = 0.0; // Night Shift Differential (10PM - 6AM)
    
    private int totalAbsences = 0;
    private int paidLeavesUsed = 0;

    // --- ADDERS ---
    public void addBasicWorked(double hrs) { this.basicWorkedHours += hrs; }
    public void addLateUndertime(double hrs) { this.lateUndertimeHours += hrs; }
    public void addRegularOt(double hrs) { this.regularOtHours += hrs; }
    public void addRestDay(double hrs) { this.restDayHours += hrs; }
    public void addSpecialHoliday(double hrs) { this.specialHolidayHours += hrs; }
    public void addRegularHoliday(double hrs) { this.regularHolidayHours += hrs; }
    public void addNsd(double hrs) { this.nsdHours += hrs; }
    public void addAbsence() { this.totalAbsences++; }
    public void addPaidLeave() { this.paidLeavesUsed++; }

    // --- GETTERS ---
    public double getBasicWorkedHours() { return basicWorkedHours; }
    public double getLateUndertimeHours() { return lateUndertimeHours; }
    public double getRegularOtHours() { return regularOtHours; }
    public double getRestDayHours() { return restDayHours; }
    public double getSpecialHolidayHours() { return specialHolidayHours; }
    public double getRegularHolidayHours() { return regularHolidayHours; }
    public double getNsdHours() { return nsdHours; }
    public int getTotalAbsences() { return totalAbsences; }
    public int getPaidLeavesUsed() { return paidLeavesUsed; }
    
    public AttendanceSummary(double basicWorkedHours, double regularOtHours, double lateUndertimeHours) {
    this.basicWorkedHours = basicWorkedHours;
    this.regularOtHours = regularOtHours;
    this.lateUndertimeHours = lateUndertimeHours;
    }
}
